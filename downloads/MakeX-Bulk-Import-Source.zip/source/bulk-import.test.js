'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path');
const Core=require('./bulk-core');const {fixture,countFiles}=require('./test-support');const items=require('./manifest.json');const source=require('/workspace/ppt-work/tech-courseware-all/manifest.json');const files=new Map(source.map(d=>[d.id,'/workspace/ppt-work/tech-courseware-all/output/'+d.pptx]));const getBytes=async id=>new Uint8Array(await fs.readFile(files.get(id)));
function preserved(actual,original){const copy=structuredClone(actual);for(const key of ['inspire','explorer','explorer2','challenge'])for(let i=0;i<copy[key].length;i++){const c=copy[key][i],old=original[key][i];if(c.ppts){c.ppts=c.ppts.filter(p=>p.coursewareCollection!=='makex-tech-49-v1');if(old.ppts===undefined)delete c.ppts;}}assert.deepEqual(copy,original);}
test('course matching respects year, normalization, duplicate names and explicit manual choices',()=>{
 const data={inspire:[],challenge:[],explorer:[{name:'ＡＩ Camera 识别',ppts:[]}],explorer2:[{name:'AI Camera识别'}]};const a={id:'a',category:'explorer',sourceName:'AI Camera识别',title:'AI Camera识别'},b={...a,id:'b',category:'explorer2'};
 const plan=Core.buildPlan(data,[a,b]);assert.deepEqual(plan.map(p=>p.index),[0,0]);data.explorer.push({name:'AI Camera识别'});assert.equal(Core.buildPlan(data,[a])[0].index,-1);assert.equal(Core.buildPlan(data,[a],{a:1})[0].index,1);assert.throws(()=>Core.buildPlan(data,[a,{...a,id:'c'}],{a:0,c:0}),/同一课程/);assert.throws(()=>Core.baseURL('https://example.com'),/本机服务/);
});
test('all 49 real PPTs import through the original server with backup and repeat without duplicates',async t=>{
 const f=await fixture(t);const events=[];const result=await Core.runImport({baseUrl:f.base,items,getBytes,onEvent:e=>events.push(e)});assert.equal(result.added,49);assert.equal(result.skipped,0);const saved=await f.read();preserved(saved,f.data);
 const backup=JSON.parse(await fs.readFile(path.join(f.dir,result.backup),'utf8'));assert.deepEqual(backup,f.data);
 for(const item of items){const lesson=saved[item.category].find(c=>c.name===item.sourceName);const attachment=lesson.ppts.find(p=>p.coursewareId===item.id);assert.ok(attachment,item.id);assert.equal(await Core.digest(await fs.readFile(path.join(f.dir,attachment.path))),item.sha256);}
 const again=await Core.runImport({baseUrl:f.base,items,getBytes});assert.equal(again.added,0);assert.equal(again.skipped,49);assert.equal(again.backup,null);assert.deepEqual(await f.read(),saved);assert.equal(events.filter(e=>e.phase==='uploaded').length,49);
});
test('bad PPT bytes stop before backup or course mutation',async t=>{
 const f=await fixture(t);await assert.rejects(Core.runImport({baseUrl:f.base,items:items.slice(0,1),getBytes:async()=>new Uint8Array([1,2,3])}),e=>e.code==='BAD_PPT');assert.deepEqual(await f.read(),f.data);assert.equal(await countFiles(path.join(f.dir,'E:','ppt')),0);
});
test('concurrent course edits abort metadata save and preserve the new edit',async t=>{
 const f=await fixture(t);await assert.rejects(Core.runImport({baseUrl:f.base,items:items.slice(0,1),getBytes,onEvent:async e=>{if(e.phase==='uploaded'){const d=await f.read();d.explorer[0].procedure='其他教师刚写入的内容';await fs.writeFile(path.join(f.dir,'makex_data.json'),JSON.stringify(d));}}}),e=>e.code==='DATA_CHANGED');const d=await f.read();assert.equal(d.explorer[0].procedure,'其他教师刚写入的内容');assert.ok(!(d.explorer[0].ppts||[]).some(p=>p.coursewareCollection==='makex-tech-49-v1'));
});
test('backup failure prevents PPT upload and metadata mutation',async t=>{
 const f=await fixture(t);let uploaded=0;const fetcher=async(url,init)=>{if(url.includes('/upload?cat=other'))return new Response(JSON.stringify({error:'read only'}),{status:500,headers:{'Content-Type':'application/json'}});if(url.includes('/upload?'))uploaded++;return fetch(url,init);};await assert.rejects(Core.runImport({baseUrl:f.base,items:items.slice(0,1),getBytes,fetch:fetcher}),e=>e.code==='UPLOAD_FAILED');assert.equal(uploaded,0);assert.deepEqual(await f.read(),f.data);
});
test('lost save response is resolved by reading the saved data rather than writing again',async t=>{
 const f=await fixture(t);let posts=0;const fetcher=async(url,init)=>{const r=await fetch(url,init);if(url.endsWith('/update')&&init.method==='POST'){posts++;await r.arrayBuffer();throw Error('connection lost after server saved');}return r;};const result=await Core.runImport({baseUrl:f.base,items:items.slice(0,1),getBytes,fetch:fetcher});assert.equal(result.added,1);assert.equal(posts,1);preserved(await f.read(),f.data);
});
