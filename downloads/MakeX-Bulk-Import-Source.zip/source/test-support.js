'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');const {spawn,execFileSync}=require('node:child_process');const {once}=require('node:events');
const repo='/workspace/ChatGPT-caoweiming';
async function fixture(t,edit){
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'makex-bulk-test-'));const data=JSON.parse(await fs.readFile('/workspace/ppt-work/original-makex_data.json','utf8'));data.explorer[0].objectives='教师本机修改的目标，应完整保留';data.explorer[0].teacherExtra={note:'keep this',nested:[1,2]};if(edit)edit(data);
 // Test the unchanged, original server, not an importer-specific mock API.
 const server=execFileSync('git',['show','HEAD:server.js'],{cwd:repo,encoding:'utf8'});await fs.writeFile(path.join(dir,'server.js'),server);
 for(const file of ['sync-courses.js','managed-git-sync.js'])await fs.copyFile(path.join(repo,file),path.join(dir,file));await fs.writeFile(path.join(dir,'makex_data.json'),JSON.stringify(data));await fs.writeFile(path.join(dir,'index.html'),'<html>MakeX fixture</html>');
 await fs.writeFile(path.join(dir,'start.js'),"const http=require('node:http');const listen=http.Server.prototype.listen;http.Server.prototype.listen=function(...args){this.once('listening',()=>console.log('TEST_PORT='+this.address().port));return listen.apply(this,args)};require('./server');");
 const child=spawn(process.execPath,['start.js'],{cwd:dir,env:{...process.env,PORT:'0'},stdio:['ignore','pipe','pipe']});let stderr='';child.stderr.on('data',c=>stderr+=c);
 const port=await new Promise((resolve,reject)=>{let out='';const timeout=setTimeout(()=>reject(Error('startup timeout '+stderr)),10000);child.stdout.on('data',c=>{out+=c;const m=out.match(/TEST_PORT=(\d+)/);if(m){clearTimeout(timeout);resolve(m[1]);}});child.once('exit',code=>{clearTimeout(timeout);reject(Error('server exited '+code+' '+stderr));});});
 async function cleanup(){if(child.exitCode===null){child.kill();await once(child,'exit');}await fs.rm(dir,{recursive:true,force:true});}
 if(t)t.after(cleanup);
 return {dir,data,base:'http://localhost:'+port,cleanup,read:async()=>JSON.parse(await fs.readFile(path.join(dir,'makex_data.json'),'utf8'))};
}
async function countFiles(root){let count=0;for(const e of await fs.readdir(root,{withFileTypes:true})){if(e.isDirectory())count+=await countFiles(path.join(root,e.name));else count++;}return count;}
module.exports={fixture,countFiles};
