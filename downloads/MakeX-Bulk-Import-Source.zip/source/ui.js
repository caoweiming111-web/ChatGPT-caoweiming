'use strict';
(function(){
const $=id=>document.getElementById(id),Core=MakeXBulk,master=new Map(MANIFEST.map(d=>[d.id,d]));
const state={items:[],sources:new Map(),data:null,overrides:{},busy:false,controller:null,backupData:null,log:[],result:null};
const escMessage=e=>e&&e.message||String(e);
function log(message){const line=new Date().toLocaleTimeString()+'  '+message;state.log.push(line);if(state.log.length>500)state.log.shift();$('log').textContent=state.log.join('\n');$('log').scrollTop=$('log').scrollHeight;}
function status(message,kind=''){ $('status').textContent=message;$('status').className=kind;}
function ready(){let count=0;try{if(state.data)count=Core.buildPlan(state.data,state.items,state.overrides).filter(p=>p.index>=0).length;}catch{}
 $('start').disabled=state.busy||!state.data||!count||!$('paused').checked;$('connect').disabled=state.busy;$('zip-files').disabled=state.busy;$('server').disabled=state.busy;$('paused').disabled=state.busy;$('backup-download').disabled=!state.backupData;
}
function renderPlan(){
 const table=$('plan-body');table.replaceChildren();
 if(!state.data||!state.items.length){$('plan-section').hidden=true;ready();return;}
 let plan;try{plan=Core.buildPlan(state.data,state.items,state.overrides);}catch(e){status(e.message,'error');ready();return;}
 $('plan-section').hidden=false;let matched=0;
 for(const p of plan){const tr=document.createElement('tr');for(const t of [p.item.category==='explorer'?'第一年':'第二年',p.item.title]){const td=document.createElement('td');td.textContent=t;tr.append(td);}
  const td=document.createElement('td'),select=document.createElement('select');select.setAttribute('aria-label','为'+p.item.title+'选择课程');const skip=document.createElement('option');skip.value='-1';skip.textContent='暂不导入 / 请选择目标课程';select.append(skip);
  state.data[p.item.category].forEach((c,i)=>{if(!c||typeof c!=='object'||!c.name)return;const o=document.createElement('option');o.value=String(i);o.textContent=(i+1)+' · '+c.name;select.append(o);});select.value=String(p.index);select.disabled=state.busy;select.onchange=()=>{state.overrides[p.item.id]=Number(select.value);renderPlan();};td.append(select);tr.append(td);
  const result=document.createElement('td');result.textContent=p.index>=0?'已匹配':p.reason;result.className=p.index>=0?'ok':'error';tr.append(result);table.append(tr);if(p.index>=0)matched++;
 }
 $('match-summary').textContent='已载入 '+state.items.length+' 份 PPT；匹配 '+matched+' 节课程，未匹配/暂不导入 '+(state.items.length-matched)+' 份。';ready();
}
async function extract(zip,path,limit){
 let saw=false;const files=fflate.unzipSync(zip,{filter:e=>{if(e.name!==path)return false;saw=true;if(e.originalSize>limit)throw Error('文件大小超出预期：'+path);return true;}});if(!saw||!files[path])throw Error('课件包缺少文件：'+path);return files[path];
}
async function readPackages(files){
 if(!files.length)return;if(files.length>3)throw Error('请一次选择1至3个课件ZIP包。');state.sources.clear();state.items=[];state.overrides={};$('packages').textContent='正在读取课件包…';
 for(const file of files){
  if(file.size>200*1024*1024)throw Error('请使用已提供的第一年上册、下册、第二年ZIP原包。');const zip=new Uint8Array(await file.arrayBuffer());const entries=new Map();const manifests=fflate.unzipSync(zip,{filter:e=>{if(entries.has(e.name))throw Error('课件包有重复文件名，请重新下载。');entries.set(e.name,e);if(e.name.endsWith('/manifest.json')){if(e.originalSize>2*1024*1024)throw Error('清单过大。');return true;}return false;}});
  const paths=Object.keys(manifests);if(paths.length!==1)throw Error('这不是49课科技风课件包，请选择上次下载的三个课件ZIP。');const path=paths[0],root=path.slice(0,-'manifest.json'.length);let rows;try{rows=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(manifests[path]));}catch{throw Error('课件包清单损坏，请重新下载。');}if(!Array.isArray(rows)||rows.length<1||rows.length>49)throw Error('课件清单格式不正确。');
  for(const row of rows){const item=master.get(row.id);if(!item)throw Error('课件包包含未知课程：'+String(row.id));if(row.pptx!=='PPT课件/'+item.fileName)throw Error('课件路径与已发布版本不一致：'+item.title);const full=root+row.pptx;const info=entries.get(full);if(!info||info.originalSize!==item.bytes)throw Error('课件文件缺失或大小不同：'+item.title);if(![0,8].includes(info.compression))throw Error('课件压缩格式不受支持。');
   if(!state.sources.has(item.id))state.sources.set(item.id,{zip,path:full});
  }
  log('已读取：'+file.name+'（'+rows.length+'课）');await new Promise(r=>setTimeout(r,0));
 }
 state.items=MANIFEST.filter(d=>state.sources.has(d.id));$('packages').textContent='已选择 '+files.length+' 个课件包，共 '+state.items.length+' 份 PPT。';status('课件包已读取。连接 MakeX 后可预览自动匹配结果。');renderPlan();
}
$('zip-files').onchange=async()=>{try{await readPackages(Array.from($('zip-files').files));}catch(e){state.items=[];state.sources.clear();$('packages').textContent='读取失败';status(escMessage(e),'error');log(escMessage(e));renderPlan();}};
$('connect').onclick=async()=>{
 try{const base=Core.baseURL($('server').value.trim());status('正在连接 MakeX…');const r=await fetch(base+'/data.json',{cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('读取服务失败：HTTP '+r.status);const data=await r.json();if(!Core.validData(data))throw Error('未读到完整课程，请从原来的MakeX程序目录启动。');state.data=data;state.overrides={};let directory='目录信息暂不可用，请确认从平时使用的MakeX目录启动';
  try{const s=await fetch(base+'/git-sync/status',{cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(4000)});const info=await s.json();if(s.ok&&typeof info.directory==='string')directory=info.directory;}catch{}
  $('directory').textContent=directory;$('open-makex').href=base+'/';$('open-makex').hidden=false;log('连接成功：'+base+'；目录：'+directory);status('连接成功，请核对程序目录与课程匹配结果。');renderPlan();
 }catch(e){state.data=null;status('连接失败。请先启动原来的MakeX，保持服务器窗口运行；浏览器询问本地网络访问时请选择允许。\n'+escMessage(e),'error');log('连接失败：'+escMessage(e));renderPlan();}
};
$('paused').onchange=ready;
$('start').onclick=async()=>{
 if(state.busy)return;state.busy=true;state.controller=new AbortController();state.result=null;$('cancel').hidden=false;$('cancel').disabled=false;$('progress').hidden=false;$('progress').value=0;renderPlan();
 try{const result=await Core.runImport({baseUrl:$('server').value.trim(),items:state.items,overrides:state.overrides,expectedData:Core.stable(state.data),signal:state.controller.signal,getBytes:async id=>{const item=master.get(id),source=state.sources.get(id);return extract(source.zip,source.path,item.bytes);},onEvent:async event=>{log(event.message);status(event.message);if(event.total){$('progress').max=event.total;$('progress').value=event.current||0;}if(event.backupData){state.backupData=event.backupData;$('backup-path').textContent=event.backup.path;$('backup-section').hidden=false;$('backup-download').disabled=false;}if(event.phase==='saving')$('cancel').disabled=true;await new Promise(r=>setTimeout(r,0));}});
  state.result=result;status('导入完成：新增 '+result.added+' 份，已存在 '+result.skipped+' 份，未匹配/暂不导入 '+result.unmatched.length+' 份。\n重新打开MakeX查看附件。若提示浏览器数据与项目文件不同，请先备份浏览器课程，再读取项目文件。','ok');$('result-section').hidden=false;
  try{const r=await fetch(Core.baseURL($('server').value.trim())+'/data.json',{cache:'no-store',credentials:'omit'});state.data=await r.json();}catch{}
 }catch(e){status('导入停止：'+escMessage(e)+'\n日志中会保留已完成的步骤；重新导入会复用已校验的文件。','error');log('停止 ['+(e.code||'ERROR')+'] '+escMessage(e));}
 finally{state.busy=false;$('cancel').hidden=true;renderPlan();}
};
$('cancel').onclick=()=>{if(state.controller)state.controller.abort();};
function download(name,text,type='text/plain;charset=utf-8'){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
$('backup-download').onclick=()=>{if(state.backupData)download('MakeX_导入前课程备份.json',JSON.stringify(state.backupData,null,2),'application/json');};
$('log-download').onclick=()=>download('MakeX_批量导入日志.txt',state.log.join('\n'));
$('backup-download').disabled=true;if(!globalThis.crypto||!crypto.subtle){status('请使用最新版Edge或Chrome打开此HTML文件，以支持课件校验。','error');$('zip-files').disabled=true;}
window.bulkImportState=state;ready();
})();
