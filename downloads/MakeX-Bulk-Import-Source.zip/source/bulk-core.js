(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MakeXBulk=api;})(globalThis,function(){
'use strict';
const CATS={explorer:'Explorer第一年',explorer2:'Explorer第二年',other:'其他'};
class ImportError extends Error{constructor(code,message){super(message);this.code=code;}}
const fail=(code,message)=>{throw new ImportError(code,message);};
function normalizeName(value){return String(value||'').normalize('NFKC').replace(/[\s\u200b-\u200d\ufeff]+/g,'').toLowerCase();}
function stable(value){if(Array.isArray(value))return '['+value.map(stable).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+stable(value[k])).join(',')+'}';return JSON.stringify(value);}
function baseURL(value){let u;try{u=new URL(value);}catch{fail('BAD_URL','服务地址格式不正确。');}if(u.protocol!=='http:'||!['localhost','127.0.0.1'].includes(u.hostname)||u.username||u.password||u.pathname!=='/'||u.search||u.hash)fail('BAD_URL','请使用本机服务地址，例如 http://localhost:3456。');return u.origin;}
function validData(data){return data&&['inspire','explorer','explorer2','challenge'].every(k=>Array.isArray(data[k]));}
function buildPlan(data,items,overrides={}){
 if(!validData(data))fail('INVALID_DATA','服务未返回完整的 MakeX 课程数据。请从平时使用的程序目录启动服务。');
 const used=new Set();return items.map(item=>{
  if(!CATS[item.category]||item.category==='other')fail('BAD_CATEGORY','不支持的课程模块。');
  const courses=data[item.category];const names=[item.sourceName,item.title].map(normalizeName);const hits=[];
  courses.forEach((c,i)=>{if(c&&typeof c==='object'&&names.includes(normalizeName(c.name)))hits.push(i);});
  let index=Object.prototype.hasOwnProperty.call(overrides,item.id)?Number(overrides[item.id]):(hits.length===1?hits[0]:-1);
  if(!Number.isInteger(index)||index<0||index>=courses.length)index=-1;
  if(index<0)return {item,index:-1,reason:hits.length>1?'存在同名课程，需手动选择':'没有匹配名称，可手动选择或暂不导入'};
  const course=courses[index];if(!course||typeof course!=='object')fail('INVALID_COURSE','目标课程格式不正确。');
  if(course.ppts!==undefined&&!Array.isArray(course.ppts))fail('INVALID_ATTACHMENTS','课程“'+course.name+'”的附件格式不正确，未进行修改。');
  const key=item.category+':'+index;if(used.has(key))fail('DUPLICATE_TARGET','两个课件匹配到同一课程，请检查手动选择。');used.add(key);
  return {item,index,courseName:course.name,reason:hits[0]===index?'自动匹配':'手动匹配'};
 });
}
function normalizePath(value){return String(value||'').replace(/\\/g,'/').toLowerCase();}
function relativePptPath(value){const parts=String(value||'').replace(/\\/g,'/').split('/').filter(Boolean);if(parts.length<2||parts.some(x=>x==='..'||x==='.'||x.includes('\0')))fail('INVALID_PATH','服务返回的课件路径不正确。');return parts.slice(-2).map(encodeURIComponent).join('/');}
function uploadName(item,suffix=''){return ('科技风49_'+item.id+'_'+item.sha256.slice(0,12)+(suffix?'_'+suffix:'')+'.pptx').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_');}
async function digest(bytes){return Array.from(new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('');}
function aborted(signal){if(signal&&signal.aborted)fail('CANCELLED','已取消，尚未保存本轮课程附件记录。');}
async function runImport(options){
 const base=baseURL(options.baseUrl);const fetcher=options.fetch||globalThis.fetch;const signal=options.signal;const emit=async e=>{if(options.onEvent)await options.onEvent(e);};
 async function request(url,init={},timeout=45000){
  aborted(signal);const controller=new AbortController();let timed=false;const cancel=()=>controller.abort();if(signal)signal.addEventListener('abort',cancel,{once:true});
  const timer=setTimeout(()=>{timed=true;controller.abort();},timeout);
  try{return await fetcher(base+url,{...init,credentials:'omit',cache:'no-store',signal:controller.signal});}
  catch(error){if(signal&&signal.aborted)throw new ImportError('CANCELLED','已取消，尚未确认保存结果。');throw new ImportError(timed?'TIMEOUT':'NETWORK',timed?'请求超时，请检查本地服务窗口。':'无法连接 MakeX。请启动服务，并允许浏览器访问本地网络。');}
  finally{clearTimeout(timer);if(signal)signal.removeEventListener('abort',cancel);}
 }
 async function readData(){const r=await request('/data.json');if(!r.ok)fail('READ_DATA','读取课程失败：HTTP '+r.status);let data;try{data=await r.json();}catch{fail('INVALID_DATA','没有读到课程JSON，请确认地址指向 MakeX 服务。');}if(!validData(data))fail('INVALID_DATA','课程数据结构不完整，已停止导入。');return data;}
 async function fileAt(relative){const r=await request('/ppt/'+relative.split('/').map(encodeURIComponent).join('/'));if(r.status===404)return null;if(!r.ok)fail('READ_FILE','检查课件文件失败：HTTP '+r.status);return new Uint8Array(await r.arrayBuffer());}
 async function recordFile(record){return fileAt(decodeURIComponent(relativePptPath(record.path)));}
 async function putFile(cat,name,bytes,expectedHash){
  let response,body,originalError;
  try{response=await request('/upload?cat='+encodeURIComponent(cat)+'&name='+encodeURIComponent(name),{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:bytes},60000);try{body=await response.json();}catch{}if(!response.ok||!body||!body.ok)fail('UPLOAD_FAILED',body&&body.error?'文件保存失败：'+body.error:'文件保存失败：HTTP '+response.status);}
  catch(error){if(!['NETWORK','TIMEOUT'].includes(error.code))throw error;originalError=error;}
  const rel=CATS[cat]+'/'+name;const checked=await fileAt(rel);
  if(!checked||await digest(checked)!==expectedHash){if(originalError)throw originalError;fail('VERIFY_FILE','文件回读校验失败：'+name+'；未保存课程记录。');}
  return {name:body&&body.name||name,path:body&&body.path||rel};
 }
 const baseline=await readData();if(options.expectedData&&stable(baseline)!==options.expectedData)fail('DATA_CHANGED','课程数据在预览后发生变化，请重新连接并匹配。');
 const allPlan=buildPlan(baseline,options.items,options.overrides);const plan=allPlan.filter(p=>p.index>=0);if(!plan.length)fail('NO_MATCH','没有匹配到可导入的课程，请先检查课程名称。');
 const prepared=[];let done=0;
 for(const p of plan){aborted(signal);await emit({phase:'verify',current:++done,total:plan.length,message:'校验课件：'+p.item.title});const bytes=await options.getBytes(p.item.id);if(bytes.length!==p.item.bytes||await digest(bytes)!==p.item.sha256)fail('BAD_PPT','课件内容与已发布版本不一致：'+p.item.title+'。请重新下载对应的科技风课件包。');}
 // Resolve existing attachments and files before writing anything.
 done=0;for(const p of plan){
  aborted(signal);await emit({phase:'check',current:++done,total:plan.length,message:'检查已有附件：'+p.item.title});const attachments=baseline[p.item.category][p.index].ppts||[];let existing=null;
  for(const a of attachments){if(!a||!a.path)continue;const leaf=String(a.path).replace(/\\/g,'/').split('/').pop();if(a.coursewareId===p.item.id&&a.coursewareSha256===p.item.sha256||a.name===p.item.fileName||leaf===p.item.fileName||leaf===uploadName(p.item)){
    const data=await recordFile(a);if(data&&data.length===p.item.bytes&&await digest(data)===p.item.sha256){existing=a;break;}
   }}
  if(existing){prepared.push({...p,existing});continue;}
  let name=uploadName(p.item),found=await fileAt(CATS[p.item.category]+'/'+name),reused=null;
  if(found&&found.length===p.item.bytes&&await digest(found)===p.item.sha256)reused={name,path:CATS[p.item.category]+'/'+name};
  else if(found){name=uploadName(p.item,Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7));await emit({phase:'note',message:'同名文件内容不同，保留原文件并使用新名称：'+p.item.title});}
  prepared.push({...p,name,reused});
 }
 const skipped=prepared.filter(p=>p.existing).length;const pending=prepared.filter(p=>!p.existing);
 if(!pending.length){if(stable(await readData())!==stable(baseline))fail('DATA_CHANGED','检查期间课程数据变化，请重新读取后核对。');await emit({phase:'complete',message:'所选课件均已导入，无需重复写入。'});return {added:0,skipped,unmatched:allPlan.filter(p=>p.index<0).map(p=>p.item.title),backup:null};}
 if(stable(await readData())!==stable(baseline))fail('DATA_CHANGED','检查期间课程发生变化，未写入附件。请暂停编辑后重新读取。');
 aborted(signal);await emit({phase:'backup',message:'先保存并回读课程备份…'});
 const backupBytes=new TextEncoder().encode(JSON.stringify(baseline,null,2));const backupName='MakeX_before_tech49_'+new Date().toISOString().replace(/[^0-9TZ]/g,'')+'_'+Math.random().toString(36).slice(2,8)+'.json';const backup=await putFile('other',backupName,backupBytes,await digest(backupBytes));await emit({phase:'backup',message:'备份已验证：'+backup.path,backup,backupData:baseline});
 done=0;for(const p of prepared){
  aborted(signal);if(p.existing)continue;await emit({phase:'upload',current:++done,total:pending.length,message:(p.reused?'复用已保存文件：':'导入课件：')+p.item.title});const file=p.reused||await putFile(p.item.category,p.name,await options.getBytes(p.item.id),p.item.sha256);p.saved=file;await emit({phase:'uploaded',current:done,total:pending.length,message:'课件文件已校验：'+p.item.title});
 }
 aborted(signal);if(stable(await readData())!==stable(baseline))fail('DATA_CHANGED','导入文件期间有人修改了课程，已停止保存附件记录。现有课程未被覆盖；请暂停编辑后重新导入，已上传文件会自动复用。');
 const merged=JSON.parse(JSON.stringify(baseline));
 for(const p of prepared){if(p.existing)continue;const lesson=merged[p.item.category][p.index];if(!lesson.ppts)lesson.ppts=[];lesson.ppts.push({name:p.item.fileName,path:p.saved.path,coursewareId:p.item.id,coursewareSha256:p.item.sha256,coursewareCollection:'makex-tech-49-v1'});}
 await emit({phase:'saving',message:'保存课程附件记录，请等待结果确认…'});let saveError=null;
 try{const r=await request('/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(merged)});let b;try{b=await r.json();}catch{}if(!r.ok||!b||!b.ok)fail('SAVE_FAILED',b&&b.error?'保存课程失败：'+b.error:'保存课程失败：HTTP '+r.status);}
 catch(error){saveError=error;}
 let actual;try{actual=await readData();}catch{fail('SAVE_UNCONFIRMED','保存结果尚未确认。请保留备份，重新连接查看课程，勿把超时当成未保存。');}
 if(stable(actual)!==stable(merged)){if(saveError)throw saveError;fail('SAVE_UNCONFIRMED','保存后的数据与预期不同，请保留备份并重新读取核对。');}
 const result={added:pending.length,skipped,unmatched:allPlan.filter(p=>p.index<0).map(p=>p.item.title),backup:backup.path};await emit({phase:'complete',message:'导入完成：新增 '+result.added+' 份，已存在 '+skipped+' 份。',result});return result;
}
return {ImportError,normalizeName,stable,baseURL,validData,buildPlan,relativePptPath,uploadName,digest,runImport};
});
