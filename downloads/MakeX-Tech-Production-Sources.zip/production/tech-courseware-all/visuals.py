from pathlib import Path
import math,re,textwrap,unicodedata
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from PIL import Image
ROOT=Path('/workspace/ppt-work/tech-courseware-all')
C={'bg':'000026','panel':'082456','panel2':'102F64','red':'FF343C','blue':'178AE4','white':'FFFFFF','muted':'D5DFF3','yellow':'FFC847','green':'56DAB8','black':'030818'}
def rgb(c):return RGBColor.from_string(C.get(c,c))
def no_effect(sh):
 sp=sh._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sp is not None:sp.append(OxmlElement('a:effectLst'))
 return sh
def rect(s,x,y,w,h,color='panel',border=None,kind=MSO_SHAPE.RECTANGLE):
 a=s.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h));a.fill.solid();a.fill.fore_color.rgb=rgb(color)
 if border:a.line.color.rgb=rgb(border);a.line.width=Pt(1.3)
 else:a.line.fill.background()
 return no_effect(a)
def poly(s,pts,color=None,border=None,width=1.5):
 b=s.shapes.build_freeform(Inches(pts[0][0]),Inches(pts[0][1]));b.add_line_segments([(Inches(x),Inches(y))for x,y in pts[1:]],close=True);a=b.convert_to_shape()
 if color:a.fill.solid();a.fill.fore_color.rgb=rgb(color)
 else:a.fill.background()
 if border:a.line.color.rgb=rgb(border);a.line.width=Pt(width)
 else:a.line.fill.background()
 return no_effect(a)
def frame(s,x,y,w,h,color='panel',border='red',cut=.16):return poly(s,[(x+cut,y),(x+w-cut,y),(x+w,y+cut),(x+w,y+h-cut),(x+w-cut,y+h),(x+cut,y+h),(x,y+h-cut),(x,y+cut)],color,border)
def line(s,x,y,xx,yy,color='red',width=2.5,arrow=False,dash=False):
 a=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x),Inches(y),Inches(xx),Inches(yy));a.line.color.rgb=rgb(color);a.line.width=Pt(width)
 ln=a._element.spPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ln')
 if arrow:e=OxmlElement('a:tailEnd');e.set('type','triangle');ln.append(e)
 if dash:e=OxmlElement('a:prstDash');e.set('val','dash');ln.append(e)
 return a
def _units(t):return sum(1 if unicodedata.east_asian_width(ch)in'WF'else .56 for ch in t)
def _wrap(t,maxunits):
 out=[]
 for raw in str(t).split('\n'):
  part='';n=0
  for ch in raw:
   u=1 if unicodedata.east_asian_width(ch)in'WF'else .56
   if n+u>maxunits and part:out.append(part);part='';n=0
   part+=ch;n+=u
  out.append(part)
 return out
TEXT_AUDIT=[]
def txt(s,t,x,y,w,h,size=23,color='white',bold=False,align=None,font='Noto Sans CJK SC',wrap=True):
 t=str(t).removesuffix('。');actual=size
 if wrap:
  rows=_wrap(t,w*72/actual*.97)
  while actual>11:
   rows=_wrap(t,w*72/actual*.97)
   if len(rows)*actual*1.27<=h*72:break
   actual-=.5
 else:rows=t.split('\n')
 a=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));a.fill.background();a.line.fill.background();tf=a.text_frame;tf.word_wrap=False;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
 for i,row in enumerate(rows):
  p=tf.paragraphs[0]if i==0 else tf.add_paragraph();p.text=row;p.font.name=font;p.font.size=Pt(actual);p.font.bold=bold;p.font.color.rgb=rgb(color);p.space_after=Pt(actual*.12);p.line_spacing=1.10
  if align is not None:p.alignment=align
 TEXT_AUDIT.append({'text':t,'requested':size,'actual':actual,'x':x,'y':y,'w':w,'h':h})
 return a
def bg(s):
 s.background.fill.solid();s.background.fill.fore_color.rgb=rgb('bg')
 poly(s,[(0,0),(1.15,0),(3.05,2.9),(2.0,3.75),(3.05,4.65),(1.15,7.5),(0,7.5),(1.55,3.75)],'230A31')
 poly(s,[(0,1.5),(1.8,3.75),(0,6),(0,5.6),(1.44,3.75),(0,1.9)],'0D376A')
 poly(s,[(0,1.9),(1.48,3.75),(0,5.6),(0,5.43),(1.32,3.75),(0,2.07)],'79102D')
 poly(s,[(13.333,0),(12.2,0),(10.4,2.9),(11.3,3.75),(10.4,4.65),(12.2,7.5),(13.333,7.5),(11.8,3.75)],'06143C')
 poly(s,[(13.333,1.5),(11.5,3.75),(13.333,6),(13.333,5.6),(11.87,3.75),(13.333,1.9)],'123C70')
def photo(s,asset,q,x,y,w,h):
 path=ROOT/(asset+'.png')if asset!='intro'else Path('/workspace/ppt-work/template-study/intro-art.png')
 frame(s,x-.06,y-.06,w+.12,h+.12,'panel','red',.16)
 a=s.shapes.add_picture(str(path),Inches(x),Inches(y),width=Inches(w),height=Inches(h));left=.5 if q%2 else 0;top=.5 if q//2 else 0;rw=rh=.5;ratio=w/h
 if ratio>1.5:n=rw*1.5/ratio;top+=(rh-n)/2;rh=n
 else:n=rh*ratio/1.5;left+=(rw-n)/2;rw=n
 a.crop_left=left;a.crop_right=1-left-rw;a.crop_top=top;a.crop_bottom=1-top-rh
 return a

def robot(s,x,y,k=1,angle=0):
 body=rect(s,x+.15*k,y+.12*k,1.5*k,.85*k,'panel2',border='blue');body.rotation=angle
 for dx in [0,1.45]:
  for dy in [.12,.65]:rect(s,x+dx*k,y+dy*k,.3*k,.4*k,'blue')
 for dx in [.55,1.05]:rect(s,x+dx*k,y,.28*k,.28*k,'blue',kind=MSO_SHAPE.OVAL)
 rect(s,x+.65*k,y+.3*k,.5*k,.3*k,'red')
 line(s,x+.65*k,y+1*k,x+.4*k,y+1.3*k,'red',3);line(s,x+1.1*k,y+1*k,x+1.35*k,y+1.3*k,'red',3)
def tag(s,id,x,y,w):
 path=ROOT/'source-assets'/f'apriltag36h11-{id}.png'
 if not path.exists():raise ValueError('Missing authoritative tag asset')
 im=Image.open(path).convert('RGB');n=im.width
 rect(s,x,y,w,w,'white')
 for yy in range(n):
  for xx in range(n):
   if sum(im.getpixel((xx,yy)))<380:rect(s,x+xx*w/n,y+yy*w/n,w/n+.002,w/n+.002,'black')
 txt(s,'ID '+str(id),x,y+w+.13,w,.35,18,'white',True,PP_ALIGN.CENTER)

def pill(s,t,x,y,w=2,color='red'):rect(s,x,y,w,.48,color);txt(s,t,x+.08,y+.07,w-.16,.34,16,'white',True,PP_ALIGN.CENTER)
def node(s,t,x,y,w=2.2,h=1.1,color='panel'):frame(s,x,y,w,h,color);txt(s,t,x+.16,y+.18,w-.32,h-.3,24,'white',True,PP_ALIGN.CENTER)
def flow(s,nodes,y=3.35):
 n=len(nodes);gap=.3;w=(11.75-gap*(n-1))/n
 for i,t in enumerate(nodes):
  x=.8+i*(w+gap);node(s,t,x,y,w,1.45,'panel2'if i%2 else'panel')
  if i<n-1:line(s,x+w+.03,y+.73,x+w+gap-.03,y+.73,'red',2.5,True)
  txt(s,f'{i+1:02}',x,y-.67,w,.5,28,'white',True,PP_ALIGN.CENTER)

def coordinate(s,mode='tag',x=.95,y=2.6,w=7.3,h=3.9):
 if mode=='stage':
  frame(s,x,y,w,h,'panel2','blue');cx=x+w/2;cy=y+h/2
  line(s,x+.35,cy,x+w-.3,cy,'white',1.5,True);line(s,cx,y+h-.35,cx,y+.3,'white',1.5,True)
  txt(s,'(0,0)',cx+.15,cy+.1,1.3,.35,18);txt(s,'x →',x+w-.95,cy+.15,.85,.3,17);txt(s,'y ↑',cx+.2,y+.35,.9,.3,17)
  rect(s,cx+1.25,cy-1.1,.5,.5,'yellow',kind=MSO_SHAPE.OVAL);line(s,cx+1.5,cy-.45,cx+1.5,cy+.9,'red',3,True)
  txt(s,'y 逐步减小',x+.45,y+h-.65,3.8,.4,23,'white',True)
  return
 frame(s,x,y,w,h,'panel2','blue');line(s,x+.45,y+.4,x+w-.3,y+.4,'white',1.4,True);line(s,x+.45,y+.4,x+.45,y+h-.3,'white',1.4,True)
 txt(s,'(0,0)',x+.7,y+.04,1.4,.3,16);txt(s,'x →',x+w-1.0,y+.55,.9,.3,16);txt(s,'y ↓',x+.07,y+1.0,.9,.3,16)
 if mode=='stage':
  line(s,x+w/2,y+.6,x+w/2,y+h-.5,'muted',1);line(s,x+.6,y+h/2,x+w-.5,y+h/2,'muted',1);rect(s,x+w*.65,y+h*.3,.55,.55,'yellow',kind=MSO_SHAPE.OVAL);line(s,x+w*.68,y+h*.52,x+w*.68,y+h*.85,'red',3,True);txt(s,'y 逐步减小',x+1.0,y+h-.8,3.6,.4,20)
 elif mode=='line':
  pts=[(x+w*.45,y+h*.85),(x+w*.48,y+h*.65),(x+w*.65,y+h*.4),(x+w*.62,y+h*.2)]
  for a,b in zip(pts,pts[1:]):line(s,*a,*b,'white',10)
  line(s,x+w*.5,y+.6,x+w*.5,y+h-.4,'red',1.5,dash=True);txt(s,'偏差',x+w*.52,y+h*.58,1.7,.4,20,'yellow')
 else:
  tag(s,0,x+w*.57,y+h*.22,1.6);line(s,x+w*.5,y+.7,x+w*.5,y+h-.4,'red',1.2,dash=True);txt(s,'640 × 480 示例',x+.8,y+h-.65,4,.35,17,'muted')

def draw_sensor(s,mode):
 if mode=='ultrasonic':
  frame(s,1,3.35,2.8,1.8,'panel2','blue')
  for x in [1.4,2.75]:rect(s,x,3.82,.65,.65,'white',kind=MSO_SHAPE.OVAL);rect(s,x+.12,3.94,.41,.41,'panel',kind=MSO_SHAPE.OVAL)
  rect(s,10.8,2.65,.4,3.55,'red');line(s,4.2,3.65,10.2,3.65,'red',3,True);line(s,10.2,4.75,4.2,4.75,'blue',3,True)
  txt(s,'发出',5.6,3.05,2,.45,26,'white',True);txt(s,'返回',5.6,5.05,2,.45,26,'white',True);txt(s,'障碍物',10.0,6.3,2,.4,20);txt(s,'往返时间',4.65,5.85,4.7,.6,28,'white',True,PP_ALIGN.CENTER)
 else:
  states=['0110']if mode=='line'else['1000','0110','0001']
  for n,st in enumerate(states):
   x=.9+n*4.05 if len(states)>1 else 3.0;w=3.75 if len(states)>1 else 7.1
   frame(s,x,2.65,w,3.85,'panel')
   rect(s,x+.2,3.25,w-.4,1.4,'white')
   size=.47;gap=(w-.8-4*size)/3
   active=[i for i,v in enumerate(st)if v=='1'];start=x+.4+min(active)*(size+gap)-.07;end=x+.4+max(active)*(size+gap)+size+.07
   rect(s,start,3.25,end-start,1.4,'black')
   for i,v in enumerate(st):
    xx=x+.4+i*(size+gap);rect(s,xx,4.0,size,size,'red'if v=='1'else'blue',kind=MSO_SHAPE.OVAL);txt(s,['L2','L1','R1','R2'][i],xx-.05,4.7,size+.1,.35,13,'white',False,PP_ALIGN.CENTER)
   txt(s,st,x+.2,5.5,w-.4,.6,30,'white',True,PP_ALIGN.CENTER)

def draw_servo(s,angles):
 for i,a in enumerate(angles):
  x=1.0+i*4.1;frame(s,x,2.6,3.65,3.85,'panel');cx=x+1.82;cy=4.2
  rect(s,cx-.75,cy-.75,1.5,1.5,'panel2',border='blue',kind=MSO_SHAPE.OVAL)
  t=math.radians(a-90);line(s,cx,cy,cx+1.0*math.sin(t),cy-1.0*math.cos(t),'red',8)
  rect(s,cx-.12,cy-.12,.24,.24,'white',kind=MSO_SHAPE.OVAL)
  txt(s,str(a)+'°',x+.25,5.55,3.15,.55,29,'white',True,PP_ALIGN.CENTER)

def draw_feedback(s,mode):
 for x,t in [(1,'目标 / 基准'),(4.25,'误差与增益'),(8,'电机输出')]:node(s,t,x,3.15,2.85,1.3)
 line(s,3.9,3.8,4.2,3.8,'red',3,True);line(s,7.15,3.8,7.9,3.8,'red',3,True)
 line(s,9.4,4.5,9.4,5.65,'blue',2);line(s,9.4,5.65,2.4,5.65,'blue',2);line(s,2.4,5.65,2.4,4.5,'blue',2,True)
 txt(s,'传感器反馈',4.8,5.82,4,.4,23,'muted',True,PP_ALIGN.CENTER)
 if mode=='joystick':txt(s,'Ly：前后    Rx：转向',2.2,2.3,8.8,.5,28,'white',True,PP_ALIGN.CENTER)
 else:txt(s,'纠偏量 = Kp × 误差',2.2,2.3,8.8,.5,28,'white',True,PP_ALIGN.CENTER)

def draw_gyro(s,mode):
 if mode=='axes':
  for i,(label,theta)in enumerate([('偏航：转弯',0),('俯仰：点头',20),('横滚：侧倾',-20)]):
   x=.95+i*4.08;frame(s,x,2.6,3.73,3.8,'panel');robot(s,x+.95,3.6,.95,theta);line(s,x+.5,5.25,x+3.25,5.25,'blue',2,True);txt(s,label,x+.2,5.65,3.3,.5,23,'white',True,PP_ALIGN.CENTER)
 elif mode=='mirror':
  for i,lab in enumerate(['左侧路径','右侧路径']):
   x=1+i*6.2;frame(s,x,2.6,5.55,3.75,'panel');robot(s,x+.6,4.6,.65);direction=1 if i==0 else-1;sx=x+1.5 if i==0 else x+4.0;line(s,sx,5.0,sx,3.5,'blue',3,True);line(s,sx,3.5,sx+direction*1.4,3.5,'red',3,True);txt(s,lab,x+.25,5.7,5,.4,23,'white',True,PP_ALIGN.CENTER)
 else:
  robot(s,1.65,3.25,1.5);line(s,6.4,5.5,6.4,2.6,'blue',4,True);line(s,6.4,5.5,9.0,3.0,'red',4,True);txt(s,'目标角度',6.65,2.45,3,.5,26,'blue',True);txt(s,'当前角度',9.05,3.0,3,.5,26,'red',True);txt(s,'误差 = 目标 − 当前',5.7,5.75,6.1,.6,29,'white',True,PP_ALIGN.CENTER)

def draw_mechanism(s,mode,values=None):
 if mode in ['wheels','swerve']:
  if mode=='swerve':
   frame(s,1,2.55,6.5,3.95,'panel');rect(s,3.1,3.7,2.1,1.5,'panel2',border='blue');rect(s,3.6,3.1,1.1,.5,'red');rect(s,3.65,4.9,1,1.0,'blue');line(s,2.3,3.1,3.45,3.35,'red',2,True);txt(s,'转向舵机',.95,2.9,2.2,.5,23);txt(s,'驱动电机',8,3.3,3.5,.6,27);txt(s,'轮子滚动',8,4.8,3.5,.6,27)
  else:
   for i,n in enumerate([3,4,4]):
    x=.95+i*4.1;frame(s,x,2.55,3.7,3.95,'panel');rect(s,x+.75,3.3,2.2,1.75,'panel2',border='blue')
    points=[(.5,3.5),(2.8,3.5),(1.7,5)]if n==3 else[(.5,3.4),(2.8,3.4),(.5,4.8),(2.8,4.8)]
    for dx,yy in points:rect(s,x+dx,yy,.4,.55,'blue')
    txt(s,['三点支撑','四角布局','自定义布局'][i],x+.2,5.65,3.3,.5,22,'white',True,PP_ALIGN.CENTER)
 elif mode=='balance':
  for i,high in enumerate([False,True]):
   x=1+i*6.2;frame(s,x,2.6,5.55,3.85,'panel');poly(s,[(x+1,5.7),(x+4.5,5.7),(x+3.75,4.95),(x+1.7,4.95)],'panel2','blue');cx=x+2.75;cy=3.4 if high else 4.55
   rect(s,cx-.2,cy-.2,.4,.4,'red',kind=MSO_SHAPE.OVAL);line(s,cx,cy,cx,5.55,'white',1.6,dash=True);txt(s,'重心较低'if not high else'重心升高，重新检验',x+.3,5.9,4.95,.4,20,'white',True,PP_ALIGN.CENTER)
 elif mode=='humanoid':
  rect(s,4.7,5.95,3.8,.32,'blue');rect(s,5.55,3.65,2.1,2.0,'panel2',border='blue');rect(s,5.95,2.75,1.3,.65,'blue')
  for xx in [6.15,6.75]:rect(s,xx,2.95,.25,.25,'white',kind=MSO_SHAPE.OVAL)
  for xx,side in [(5.45,-1),(7.75,1)]:
   rect(s,xx-.18,3.95,.36,.36,'red',kind=MSO_SHAPE.OVAL);line(s,xx,4.13,xx+side*1.25,3.5,'blue',10);line(s,xx+side*1.25,3.5,xx+side*1.7,4.4,'blue',9)
  rect(s,6.3,5.55,.6,.6,'red',kind=MSO_SHAPE.OVAL)
  txt(s,'左臂舵机',1.1,3.05,3.4,.65,28,'white',True);txt(s,'右臂舵机',9.0,3.05,3.4,.65,28,'white',True);txt(s,'身体旋转',9.0,5.2,3.4,.65,28,'white',True)
 elif mode in ['gripper','arm']:
  rect(s,2,5.9,3.4,.35,'blue');line(s,3.7,5.9,3.7,4.4,'blue',12);line(s,3.7,4.4,5.9,3.65,'blue',12);line(s,5.9,3.65,7.4,4.0,'blue',10)
  for x,y in [(3.7,4.4),(5.9,3.65),(7.4,4.0)]:rect(s,x-.22,y-.22,.44,.44,'red',kind=MSO_SHAPE.OVAL)
  line(s,7.4,4.0,8.1,3.5,'red',5);line(s,7.4,4.0,8.1,4.5,'red',5);rect(s,8.2,3.8,.7,.7,'yellow',kind=MSO_SHAPE.CUBE)
  for y,t in [(2.7,'旋转 / 定位'),(4.1,'俯仰 / 升降'),(5.5,'夹紧 / 释放')]:txt(s,t,9.25,y,3.2,.65,25,'white',True)
 elif mode in ['belt','lift','rack']:
  for x in [4.0,6.0]:rect(s,x,2.6,.2,3.6,'blue')
  if mode=='rack':
   rect(s,4.9,2.6,.16,3.6,'blue');
   for j in range(12):rect(s,4.75,2.65+j*.28,.2,.13,'blue')
   rect(s,5.5,3.9,1.1,1.1,'red',kind=MSO_SHAPE.GEAR_6)
  else:
   for y in [2.75,5.45]:rect(s,4.55,y,1.1,1.1,'blue',kind=MSO_SHAPE.OVAL)
   line(s,4.6,3.3,4.6,5.95,'red',4);line(s,5.6,3.3,5.6,5.95,'red',4)
  rect(s,3.7,4.05,2.65,.65,'panel2',border='white');line(s,7,5.8,7,3.0,'white',2.5,True);txt(s,'导向',1.3,3.3,2,.5,25);txt(s,'驱动',8.0,3.2,3,.5,27);txt(s,'有效行程',8.0,4.8,3,.5,27)
 elif mode=='heights':
  vals=values or['地面','中间高度','高位目标']
  for i,lab in enumerate(vals):
   x=1+i*4.1;h=.7+i*.8;rect(s,x,6.0-h,3.1,h,'panel2',border='blue');rect(s,x+1.1,5.4-h,.6,.6,'yellow',kind=MSO_SHAPE.CUBE);txt(s,lab,x-.05,6.15,3.3,.45,22,'white',True,PP_ALIGN.CENTER)
 elif mode in ['cam','slider_crank']:
  if mode=='cam':
   a=rect(s,3.4,4.1,2.5,1.7,'blue',kind=MSO_SHAPE.OVAL);a.rotation=-20;rect(s,4.45,3.0,.35,1.5,'red');rect(s,3.75,2.7,1.75,.35,'panel2',border='white');line(s,6.5,5.7,6.5,2.8,'white',2,True);txt(s,'凸轮',1.3,4.7,2,.5,26);txt(s,'滑块与导向',7.4,3.2,4,.6,28)
  else:
   cx,cy=3.2,4.5;rect(s,cx-.9,cy-.9,1.8,1.8,'panel2',border='blue',kind=MSO_SHAPE.OVAL);line(s,cx,cy,3.8,3.9,'red',5);line(s,3.8,3.9,7.5,4.5,'blue',6);rect(s,7.5,4.1,1.3,.8,'red');line(s,6.8,5.25,10,5.25,'white',2);line(s,6.8,3.7,10,3.7,'white',2);txt(s,'r',3.15,3.4,.7,.4,24);txt(s,'曲柄 → 连杆 → 滑块',2,6.0,9.5,.45,27,'white',True,PP_ALIGN.CENTER)
 elif mode=='dog':
  rect(s,3.2,3.25,5,1.3,'panel2',border='blue')
  for x,y in [(3.6,3.5),(7.6,3.5),(3.6,4.4),(7.6,4.4)]:rect(s,x,y,.45,.45,'red');line(s,x+.2,y+.2,x-.1,y+1.25,'blue',7)
  txt(s,'左前 / 左后',.8,3.35,2.5,.65,24);txt(s,'右前 / 右后',9.1,4.3,3.3,.65,24);txt(s,'统一编号，再测试每条腿',2,6.0,9.6,.45,27,'white',True,PP_ALIGN.CENTER)
 elif mode=='motor':
  rect(s,1.6,3.4,3.3,2.0,'blue');rect(s,4.9,3.65,3,1.5,'gray'if 'gray'in C else'panel2');rect(s,7.9,4.15,2.2,.5,'red');txt(s,'减速箱',1.6,5.7,3.3,.5,25,'white',True,PP_ALIGN.CENTER);txt(s,'电机本体',4.9,5.7,3,.5,25,'white',True,PP_ALIGN.CENTER);txt(s,'输出轴',8,5.7,2.5,.5,25,'white',True,PP_ALIGN.CENTER)
 elif mode=='barrier':
  rect(s,3,3.1,.9,2.8,'blue');a=rect(s,3.4,3.0,5.2,.3,'red');a.rotation=-25;robot(s,6,4.5,1);txt(s,'确认通过，再落闸',7.4,6.05,4.8,.45,24,'white',True)
 else:robot(s,3.3,3.1,2);txt(s,'先定位，再执行动作',7.4,4,4.5,1,30,'white',True)

def draw_plan(s,d):
 mode=d.get('mode','holes')
 if mode in ['wheel','revolve']:
  rect(s,2,2.8,3.4,3.4,'blue',kind=MSO_SHAPE.OVAL);rect(s,2.7,3.5,2,2,'panel',kind=MSO_SHAPE.OVAL);line(s,2,4.5,5.4,4.5,'white',1.5);txt(s,'外径 '+str(d.get('diameter',65))+' mm',6.7,3.15,5.1,.6,29,'white',True);txt(s,'内径 / 孔径 '+str(d.get('hole','按接口'))+' mm',6.7,4.5,5.1,.8,26,'white',True)
 elif mode=='sketch':
  rect(s,1.3,3.2,.2,.2,'red',kind=MSO_SHAPE.OVAL);line(s,3.4,3.4,5.4,5.1,'red',4);poly(s,[(7.5,5.6),(10.8,5.6),(11.8,3.0),(8.5,3.0)],'panel2','blue');txt(s,'点',.9,5.9,1.4,.4,26,'white',True);txt(s,'线',3.5,5.9,2,.4,26,'white',True);txt(s,'面',8.5,5.9,2,.4,26,'white',True)
 elif mode=='chassis':
  frame(s,2.7,2.65,6.5,3.8,'panel2','blue');
  for x in [3.1,8.2]:
   for y in [3.1,5.1]:rect(s,x,y,.65,.8,'blue')
  rect(s,5.2,3.7,1.5,1.2,'red');txt(s,'主板',5.35,4.05,1.2,.4,18,'white',True);txt(s,'轮组孔位',.7,3.4,2,.5,22);txt(s,'扩展空间',9.7,4.3,2.8,.6,23)
 elif mode=='counterbore':
  rect(s,1.5,3.45,4.5,1.9,'blue');rect(s,2.7,3.45,2.0,.6,'bg');rect(s,3.4,4.0,.6,1.35,'bg');line(s,3.7,2.8,3.7,5.9,'white',1,dash=True);txt(s,'圆柱沉孔示意',1.6,6.05,4.4,.4,24,'white',True,PP_ALIGN.CENTER);txt(s,'先核对螺钉头型\n再定孔径与深度',7,3.5,5.2,1.6,30,'white',True)
 elif mode=='box':
  poly(s,[(2.1,3.2),(6.8,3.2),(8.5,4.3),(3.8,4.3)],'panel2','blue');poly(s,[(3.8,4.3),(8.5,4.3),(8.5,6),(3.8,6)],'panel','blue');poly(s,[(2.1,3.2),(3.8,4.3),(3.8,6),(2.1,4.9)],'panel2','blue');txt(s,'开关与孔位',8.8,3.1,3.4,.6,25);txt(s,'运动空间',8.8,4.4,3.4,.6,25);txt(s,'拆装通道',8.8,5.7,3.4,.6,25)
 elif mode=='bracket':
  poly(s,[(1.8,5.0),(5.5,5.0),(6.7,5.75),(3.0,5.75)],'blue','white')
  poly(s,[(5.5,3.0),(6.7,3.75),(6.7,5.75),(5.5,5.0)],'panel2','white')
  poly(s,[(1.8,5.0),(3.0,5.75),(3.0,6.1),(1.8,5.35)],'panel','blue')
  for xx in [3.1,4.6]:rect(s,xx,5.18,.4,.25,'bg',border='white',kind=MSO_SHAPE.OVAL)
  for yy in [3.85,4.7]:rect(s,5.87,yy,.3,.42,'bg',border='white',kind=MSO_SHAPE.OVAL)
  txt(s,'安装面 A',8.0,3.05,4.1,.65,29,'white',True);txt(s,'安装面 B',8.0,4.35,4.1,.65,29,'white',True);txt(s,'两组接口，分别测绘',8.0,5.65,4.1,.65,23,'muted')
 elif mode=='connector':
  rect(s,2,3.3,3.3,2.6,'blue');rect(s,2,2.8,3.3,1.0,'blue',border='white',kind=MSO_SHAPE.OVAL);rect(s,3.2,3.1,.9,.4,'panel',kind=MSO_SHAPE.OVAL);txt(s,'教案示例：φ26 × 30 mm',6.3,3.0,5.4,.8,27,'white',True);txt(s,'通孔、侧孔、凸台\n都要对应实际接口',6.3,4.4,5.4,1.5,27,'white',True)
 else:
  x,y,w,h=2.1,3.35,2.75,2.75;frame(s,x,y,w,h,'panel2','blue');pitch=d.get('pitch',16);edge=d.get('edge',4);width=d.get('width',24);hh=d.get('height',24);hole=d.get('hole',4.2)
  n=3 if pitch==8 or mode=='base100' or width==100 else 2
  for j in range(n):
   cx=x+w/2+(j-(n-1)/2)*pitch/width*w;diam=max(.12,hole/width*w);py=y+h*(.5 if width==100 else min(.5,edge/hh));rect(s,cx-diam/2,py-diam/2,diam,diam,'bg',border='white',kind=MSO_SHAPE.OVAL)
  line(s,x,y-.28,x+w,y-.28,'white',1.5);txt(s,f'{width} mm',x-.2,y-.65,w+.4,.4,22,'white',True,PP_ALIGN.CENTER)
  txt(s,f'孔径：{hole} mm',7.5,3.0,4.7,.6,27,'white',True);txt(s,f'孔距：{pitch} mm',7.5,4.2,4.7,.6,27,'white',True);txt(s,f'基准 / 边距：{edge} mm',7.5,5.4,4.7,.7,25,'white',True)

def draw_mates(s,mode):
 frame(s,1,2.65,5.1,3.85,'panel');frame(s,6.55,2.65,5.8,3.85,'panel')
 rect(s,2.2,4.1,2.5,.5,'blue');rect(s,3.1,3.5,.7,1.8,'red')
 if mode=='fastened':txt(s,'相对运动：0个自由度',7,3.65,4.8,1.4,31,'white',True);txt(s,'固定在一起',1.4,5.65,4.3,.5,25,'white',True,PP_ALIGN.CENTER)
 elif mode=='slider':line(s,4.5,5.7,4.5,3.0,'white',3,True);txt(s,'只沿指定轴平移',7,3.65,4.8,1.4,31,'white',True);txt(s,'其余方向被约束',7,5.2,4.8,.6,23,'muted')
 else:rect(s,3.0,3.9,1,1,'panel',border='white',kind=MSO_SHAPE.OVAL);txt(s,'只绕指定轴旋转',7,3.65,4.8,1.4,31,'white',True);txt(s,'先固定基准件',7,5.2,4.8,.6,23,'muted')

def draw_meter(s,mode):
 if mode=='compare':
  for j,t in enumerate(['电压：并联测量','电流：串入回路']):
   x=1+j*6.2;frame(s,x,2.65,5.5,3.8,'panel')
   if j==0:
    line(s,x+.65,3.8,x+1.75,3.8,'white',2);resistor(s,x+1.75,3.57,1.5);line(s,x+3.55,3.8,x+4.85,3.8,'white',2)
    line(s,x+1.3,3.8,x+1.3,5.15,'blue',2);line(s,x+3.9,3.8,x+3.9,5.15,'blue',2);line(s,x+1.3,5.15,x+2.2,5.15,'blue',2);line(s,x+3.0,5.15,x+3.9,5.15,'blue',2)
    rect(s,x+2.2,4.75,.8,.8,'panel2',border='white',kind=MSO_SHAPE.OVAL);txt(s,'V',x+2.2,4.9,.8,.5,27,'white',True,PP_ALIGN.CENTER)
   else:
    line(s,x+.65,4.2,x+1.4,4.2,'white',2);rect(s,x+1.4,3.8,.8,.8,'panel2',border='white',kind=MSO_SHAPE.OVAL);txt(s,'A',x+1.4,3.95,.8,.5,27,'white',True,PP_ALIGN.CENTER);line(s,x+2.2,4.2,x+3.0,4.2,'white',2);resistor(s,x+3.0,3.97,1.15);line(s,x+4.45,4.2,x+4.9,4.2,'white',2)
   txt(s,t,x+.25,5.85,5,.45,24,'white',True,PP_ALIGN.CENTER)

 else:
  frame(s,1.3,2.5,3.6,4.0,'panel2','blue');rect(s,1.8,2.95,2.6,.85,'black');txt(s,'DC V'if mode=='voltage'else'Ω / 通断',1.95,3.15,2.3,.45,25,'white',True,PP_ALIGN.CENTER);rect(s,2.4,4.2,1.3,1.3,'panel',border='white',kind=MSO_SHAPE.OVAL)
  for xx,lab,col in [(2.0,'COM','blue'),(3.45,'VΩ','red')]:rect(s,xx,5.75,.5,.5,col,kind=MSO_SHAPE.OVAL);txt(s,lab,xx-.1,6.3,.8,.25,12,'white',False,PP_ALIGN.CENTER)
  if mode=='continuity':txt(s,'断电后\n测两点是否连通',6.2,3.1,5.6,1.9,33,'white',True)
  elif mode=='voltage':txt(s,'红笔接正端\n黑笔接负端',6.2,3.1,5.6,1.9,33,'white',True)
  else:txt(s,'先认插孔\n再选档位和量程',6.2,3.1,5.6,1.9,33,'white',True)

def draw_breadboard(s):
 frame(s,1.15,2.7,7.1,3.6,'white','red');
 for r in range(8):
  for c in range(10):rect(s,1.65+c*.6,3.1+r*.33,.1,.1,'panel',kind=MSO_SHAPE.OVAL)
 for r in [1,5]:line(s,1.7,3.15+r*.33,4.1,3.15+r*.33,'blue',5);line(s,4.7,3.15+r*.33,7.1,3.15+r*.33,'red',5)
 rect(s,4.3,2.85,.2,3.2,'muted');txt(s,'五孔一组',8.9,3.2,3.5,.7,28,'white',True);txt(s,'沟槽两侧分开',8.9,4.5,3.5,.8,26,'white',True);txt(s,'电源轨先测导通',8.9,5.7,3.5,.55,21,'muted')

def resistor(s,x,y,w=1.2,label=None):
 line(s,x-.3,y+.23,x,y+.23,'white',2);rect(s,x,y,w,.46,'panel2',border='white');line(s,x+w,y+.23,x+w+.3,y+.23,'white',2)
 if label:txt(s,label,x-.3,y-.6,w+.6,.4,17,'white',False,PP_ALIGN.CENTER)
def led(s,x,y):
 # Diode triangle, cathode bar, and two outward light arrows.
 poly(s,[(x,y),(x,y+.5),(x+.45,y+.25)],'red','white',1)
 line(s,x+.5,y-.02,x+.5,y+.52,'white',2)
 line(s,x+.23,y-.05,x+.68,y-.5,'red',2,True);line(s,x+.5,y+.1,x+.95,y-.35,'red',2,True)
 txt(s,'A',x-.1,y+.6,.25,.25,10,'muted');txt(s,'K',x+.4,y+.6,.25,.25,10,'muted')

def draw_circuit(s,mode):
 if mode in ['parallel','series']:
  if mode=='parallel':
   for yy in [3.45,5.0]:
    line(s,1.5,yy,3.5,yy,'white',2);resistor(s,3.5,yy-.23,1.2,'限流');line(s,5,yy,7.5,yy,'white',2);led(s,7.5,yy-.25);line(s,8,yy,10.9,yy,'white',2)
   line(s,1.5,3.45,1.5,5,'red',3);line(s,10.9,3.45,10.9,5,'blue',3);txt(s,'+',1.15,2.65,.7,.5,28,'red',True);txt(s,'−',10.6,2.65,.7,.5,28,'blue',True);txt(s,'每一支路：独立限流 + LED',2,5.85,9.5,.5,26,'white',True,PP_ALIGN.CENTER)
  else:
   line(s,1.5,4.0,3.2,4,'white',2);resistor(s,3.2,3.77,1.2,'限流');line(s,4.7,4,6.2,4,'white',2);led(s,6.2,3.75);line(s,6.7,4,8.3,4,'white',2);led(s,8.3,3.75);line(s,8.8,4,10.8,4,'white',2);line(s,10.8,4,10.8,5.65,'white',2);line(s,10.8,5.65,1.5,5.65,'white',2);line(s,1.5,5.65,1.5,5.0,'white',2);line(s,1.25,5,1.75,5,'white',3);line(s,1.1,4.6,1.9,4.6,'white',3);line(s,1.5,4.6,1.5,4,'white',2);txt(s,'一条通路，先核对电源与压降',1.8,2.75,9.7,.55,28,'white',True,PP_ALIGN.CENTER)
 elif mode=='divider':
  line(s,2.2,3,4,3,'red',2);resistor(s,4,2.77,1.4,'100 Ω');line(s,5.7,3,7.7,3,'white',2);resistor(s,7.7,2.77,1.4,'200 Ω');line(s,9.4,3,10.8,3,'blue',2)
  txt(s,'总电压 9 V',2,4.1,9.7,.6,34,'white',True,PP_ALIGN.CENTER);txt(s,'3 V',3.6,5.2,2.5,.6,33,'red',True,PP_ALIGN.CENTER);txt(s,'6 V',7.4,5.2,2.5,.6,33,'blue',True,PP_ALIGN.CENTER)
 else:
  line(s,1.5,3.4,3.6,3.4,'red',3);resistor(s,3.6,3.17,1.4,'限流电阻');line(s,5.3,3.4,7.3,3.4,'white',2);led(s,7.3,3.15);line(s,7.8,3.4,10.2,3.4,'white',2);line(s,10.2,3.4,10.2,5.5,'white',2);line(s,10.2,5.5,7.0,5.5,'white',2);line(s,6.8,5.5,6.0 if mode=='open_closed'else 6.8,5.1 if mode=='open_closed'else 5.5,'white',3);line(s,6.0,5.5,1.5,5.5,'white',2);line(s,1.5,5.5,1.5,4.65,'white',2);line(s,1.25,4.65,1.75,4.65,'white',3);line(s,1.1,4.25,1.9,4.25,'white',3);line(s,1.5,4.25,1.5,3.4,'white',2);txt(s,'电源 +',.95,2.8,1.8,.45,22,'red',True);txt(s,'开关',5.9,5.8,2,.4,21);txt(s,'LED',8,2.65,1.8,.4,21)

def draw_solder(s,mode):
 if mode=='steps':flow(s,['加热焊盘与引脚','少量送锡','先撤焊锡','再撤烙铁']);return
 if mode=='contact':
  rect(s,2.0,5.2,6,.4,'blue');rect(s,4.8,3.4,.16,2.3,'white');poly(s,[(6.6,3.0),(7.0,3.3),(5.3,5.1),(5.0,4.85)],'red');line(s,2.8,4.2,4.65,5.1,'yellow',4);txt(s,'同时加热焊盘与引脚',2,5.95,9.3,.5,28,'white',True,PP_ALIGN.CENTER)
 else:
  for j,lab in enumerate(['润湿完整','虚焊风险','桥连风险']):
   col='green'if j==0 else'red'
   x=1+j*4.1;frame(s,x,2.75,3.65,3.55,'panel');rect(s,x+.5,4.6,2.65,.3,'blue');rect(s,x+1.75,3.5,.12,1.5,'white');rect(s,x+1.3,4.1,1.0,.65,col if col in C else('green'if j==0 else'red'),kind=MSO_SHAPE.OVAL)
   if j==2:line(s,x+1.7,4.4,x+2.9,4.4,'red',8)
   txt(s,lab,x+.15,5.55,3.35,.5,24,'white',True,PP_ALIGN.CENTER)

def draw_np(s,mode):
 if mode=='types':
  for i,lab in enumerate(['NPN：箭头向外','PNP：箭头向内']):
   x=2+i*6.1;line(s,x,4,x+1.1,4,'white',3);line(s,x+1.1,3.2,x+1.1,4.8,'white',4);line(s,x+1.1,3.7,x+2.2,3.0,'blue',3);line(s,x+1.1,4.3,x+2.2,5.0,'red',3,arrow=i==0);txt(s,lab,x-.5,5.75,4.7,.6,28,'white',True,PP_ALIGN.CENTER)
   if i:line(s,x+2.2,5.0,x+1.35,4.45,'red',3,True)
 else:
  node(s,'安全输入',.9,3.5,2.4,1.2);node(s,'基极限流',3.9,3.5,2.4,1.2);node(s,'三极管',7,3.5,2.4,1.2);line(s,3.35,4.1,3.85,4.1,'red',3,True);line(s,6.35,4.1,6.95,4.1,'red',3,True);txt(s,'C：限流后的负载支路',7.5,2.65,4.7,.55,23,'white',True);txt(s,'E：参考地',7.5,5.35,4.7,.55,23,'white',True);line(s,8.2,3.45,8.2,3.1,'blue',2,True);line(s,8.2,4.75,8.2,5.3,'blue',2,True)

def draw_rc(s,mode):
 if mode=='storage':
  line(s,3,3.0,3,4,'red',3);line(s,2,4,4,4,'white',4);line(s,2,4.4,4,4.4,'white',4);line(s,3,4.4,3,5.6,'blue',3);txt(s,'+',4.4,3.7,.7,.5,30,'red',True);txt(s,'充电 → 储能 → 放电',6,3.55,5.8,1.5,33,'white',True)
 elif mode=='period':
  for j,col in enumerate(['red','blue']):
   y=3.1+j*1.6
   for k in range(6):rect(s,1.3+k*1.65,y,.85,.4,col if k%2==j else'panel2')
  txt(s,'A灯',.7,2.5,1.5,.4,23);txt(s,'B灯',.7,4.1,1.5,.4,23);txt(s,'一整轮：A亮 → B亮 → 回到A亮',1.4,5.9,10.4,.5,27,'white',True,PP_ALIGN.CENTER)
 else:
  x0,y0=1.4,5.8;line(s,x0,y0,11.7,y0,'white',1.5,True);line(s,x0,y0,x0,2.6,'white',1.5,True);pts=[(x0+t*9.2,5.65-2.5*math.exp(-t*3.1))for t in[i/30 for i in range(31)]]
  # Voltage decreases with time: high left, low right.
  for a,b in zip(pts,pts[1:]):line(s,*a,*b,'red',3)
  txt(s,'控制电压',1.5,2.35,3,.4,22);txt(s,'时间 →',10.5,6.0,1.8,.4,20);txt(s,'阈值与负载影响实际熄灭时刻',3.4,6.25,7.3,.4,22,'muted',False,PP_ALIGN.CENTER)

def draw_astable(s,mode):
 for i,t in enumerate(['A导通 / B截止','A截止 / B导通']):
  x=1+i*6.2;frame(s,x,2.75,5.5,3.6,'panel')
  for j in range(2):rect(s,x+1.2+j*2,3.7,.8,.8,('red'if j==i else'blue'),kind=MSO_SHAPE.OVAL)
  txt(s,t,x+.2,5.3,5.1,.65,26,'white',True,PP_ALIGN.CENTER)
 line(s,6.55,4.15,6.95,4.15,'white',2,True);txt(s,'电容耦合 → 状态交替',3.4,6.45,6.8,.4,22,'muted',False,PP_ALIGN.CENTER)

def draw_pose(s,raised=False):
 for k in range(2):
  x=3.0+k*6.0;cx=x;head=(cx,3.1);shoulderL=(cx-.8,3.8);shoulderR=(cx+.8,3.8);waist=(cx,5.2);elbowL=(cx-1.2,3.1 if raised or k==1 else 4.5);wristL=(cx-1.0,2.5 if raised or k==1 else 5.1);elbowR=(cx+1.2,4.5);wristR=(cx+1.0,5.1)
  rect(s,cx-.3,2.6,.6,.6,'white',kind=MSO_SHAPE.OVAL)
  for a,b in [(shoulderL,shoulderR),((cx,3.8),waist),(shoulderL,elbowL),(elbowL,wristL),(shoulderR,elbowR),(elbowR,wristR),(waist,(cx-.6,6.1)),(waist,(cx+.6,6.1))]:line(s,*a,*b,'blue',4)
  for a,b in [shoulderL,shoulderR,elbowL,wristL,elbowR,wristR]:rect(s,a-.08,b-.08,.16,.16,'red',kind=MSO_SHAPE.OVAL)
 txt(s,'腕高于肩 → 通常 y腕 < y肩',3.5,6.45,7,.4,22,'white',True,PP_ALIGN.CENTER)

def draw_scene(s,d,asset):
 kind=d['kind']
 if kind=='flow':flow(s,d['nodes'])
 elif kind=='photo':
  photo(s,*asset,.85,2.4,7.1,4.0)
  for i,t in enumerate(d.get('labels',[])):txt(s,f'{i+1:02}',8.5,2.65+i*1.15,.65,.6,31,'red',True);txt(s,t,9.35,2.75+i*1.15,2.9,.7,26,'white',True)
 elif kind=='sensor':draw_sensor(s,d.get('mode','ultrasonic'))
 elif kind=='gyro':draw_gyro(s,d.get('mode','error'))
 elif kind=='mechanism':draw_mechanism(s,d.get('mode','gripper'),d.get('values'))
 elif kind=='servo':draw_servo(s,d['angles'])
 elif kind=='feedback':draw_feedback(s,d.get('mode','line'))
 elif kind=='coordinate':
  coordinate(s,d.get('mode','tag'));txt(s,'先显示\n再判断\n后控制',9.0,3.0,3.3,2.6,30,'white',True)
 elif kind=='tag':
  for i,id in enumerate(d.get('ids',[0,1,2,3])):tag(s,id,1.05+i*3.05,3.05,2.3)
 elif kind=='numberline':
  centers=[2.6,6.65,10.7];line(s,centers[0],4.1,centers[-1]+.5,4.1,'white',2.5,True)
  for center,a,b in zip(centers,d['labels'],d['values']):
   rect(s,center-.15,3.95,.3,.3,'red',kind=MSO_SHAPE.OVAL);txt(s,a,center-1.6,2.85,3.2,.7,25,'white',True,PP_ALIGN.CENTER);txt(s,b,center-1.8,4.8,3.6,1.0,26,'white',True,PP_ALIGN.CENTER)
 elif kind=='formula':
  txt(s,d['formula'],1.1,2.8,11.1,1.2,39,'white',True,PP_ALIGN.CENTER)
  n=len(d.get('steps',[]));w=11.5/n
  for i,t in enumerate(d.get('steps',[])):node(s,t,.9+i*w,4.7,w-.2,1.1)
 elif kind=='experiment':
  for i,t in enumerate(d['labels']):
   x=.95+i*4.1;frame(s,x,2.75,3.72,3.6,'panel');txt(s,str(i+1),x+.3,3,.7,.7,39,'red',True);txt(s,t,x+.25,4.2,3.2,1.1,28,'white',True,PP_ALIGN.CENTER);txt(s,'先预测 → 再记录',x+.25,5.75,3.2,.4,18,'muted',False,PP_ALIGN.CENTER)
 elif kind=='types':
  for i,(a,b)in enumerate(zip(d['items'],d['labels'])):
   x=.95+i*4.1;frame(s,x,2.8,3.72,3.5,'panel');txt(s,a,x+.2,3.5,3.32,1,38,'white',True,PP_ALIGN.CENTER);txt(s,b,x+.2,5.25,3.32,.6,24,'muted',False,PP_ALIGN.CENTER)
 elif kind=='matrix':
  rows=d['rows'];cols=d['cols'];x0=.9;y0=2.7;cw=2.25;rh=.68
  for j,t in enumerate(['项目']+cols):rect(s,x0+j*cw,y0,cw-.05,rh-.04,'panel2');txt(s,t,x0+j*cw+.08,y0+.1,cw-.2,.45,18,'white',True,PP_ALIGN.CENTER)
  for i,t in enumerate(rows):
   for j in range(len(cols)+1):rect(s,x0+j*cw,y0+(i+1)*rh,cw-.05,rh-.04,'panel');txt(s,t if j==0 else'____',x0+j*cw+.08,y0+(i+1)*rh+.1,cw-.2,.45,17,'white',j==0,PP_ALIGN.CENTER)
 elif kind=='gait':
  labels=['A抬起','B后摆','A落地','B抬起','A后摆','B落地']
  for k in range(6):
   x=.95+(k%3)*4.1;y=2.55+(k//3)*2.05;frame(s,x,y,3.7,1.8,'panel');txt(s,str(k+1),x+.15,y+.12,.5,.4,22,'red',True)
   lifted=[0,3]if k in [0,1]else([1,2]if k in[3,4]else[])
   for j,(dx,dy)in enumerate([(1,.35),(2.4,.35),(1,1.0),(2.4,1.0)]):rect(s,x+dx,y+dy,.28,.28,'red'if j in lifted else'blue',kind=MSO_SHAPE.OVAL)
   txt(s,labels[k],x+.7,y+1.4,2.4,.27,15,'white',True,PP_ALIGN.CENTER)
 elif kind=='compare':
  for i,t in enumerate(d['labels']):
   x=.95+i*6.2;frame(s,x,2.65,5.52,3.8,'panel');txt(s,t,x+.25,3.0,5.02,1.25,29,'white',True,PP_ALIGN.CENTER)
   mode=d.get('mode','')
   if mode=='sensor':
    rect(s,x+.55,4.35,1.2,1.0,'blue');rect(s,x+.8,4.63,.3,.3,'white',kind=MSO_SHAPE.OVAL);edge=x+(2.65 if i==0 else 4.6);rect(s,edge,4.05,.18,1.6,'red');line(s,x+1.9,4.85,edge-.12,4.85,'white',2,True)
   elif mode in ['gait','lift','line','motion']:robot(s,x+1.7,4.6,.85)
   elif mode=='circuit':resistor(s,x+1.8,4.9,1.3);led(s,x+3.3,4.9)
   elif mode=='solder':rect(s,x+1.7,4.9,2,.3,'blue');rect(s,x+2.3,4.4,.8,.8,'red',kind=MSO_SHAPE.OVAL)
   elif mode=='pose':rect(s,x+2.35,4.6,.7,.7,'red',kind=MSO_SHAPE.OVAL)
   else:txt(s,'先做测试，再下结论',x+.3,5.5,4.92,.5,22,'muted',False,PP_ALIGN.CENTER)
 elif kind=='plan':draw_plan(s,d)
 elif kind=='mates':draw_mates(s,d.get('mode','revolute'))
 elif kind=='circuit':draw_circuit(s,d.get('mode','led'))
 elif kind=='meter':draw_meter(s,d.get('mode','ports'))
 elif kind=='breadboard':draw_breadboard(s)
 elif kind=='solder':draw_solder(s,d.get('mode','quality'))
 elif kind=='npn':draw_np(s,d.get('mode','switch'))
 elif kind=='rc':draw_rc(s,d.get('mode','discharge'))
 elif kind=='astable':draw_astable(s,d.get('mode','states'))
 elif kind=='pose':draw_pose(s,d.get('mode')=='raised')
 elif kind=='switch':
  for i,side in enumerate([0,1]):
   x=1.1+i*6.1;frame(s,x,2.65,5.4,3.8,'panel');ports=[x+1.0,x+2.6,x+4.2]
   for xx in ports:rect(s,xx,4.55,.25,.25,'white',kind=MSO_SHAPE.OVAL)
   line(s,ports[1]+.12,4.67,ports[side*2]+.12,4.67,'red',4);txt(s,'COM',ports[1]-.45,5.25,1.3,.5,23,'white',True,PP_ALIGN.CENTER);txt(s,'位置 '+str(i+1),x+.3,3.05,4.8,.5,27,'white',True,PP_ALIGN.CENTER)
 elif kind=='printer':
  frame(s,1.5,2.6,5,3.9,'panel');
  for j in range(9):rect(s,2.3,5.9-j*.22,3.4,.13,'red'if j%2==0 else'blue')
  line(s,3.1,2.95,5.3,2.95,'white',6);line(s,4.2,3,4.2,3.75,'white',6);txt(s,'模型 → 切片路径 → 逐层制造',7,3.2,5.2,2.3,33,'white',True)
 elif kind=='resistor':
  rect(s,2.0,3.5,7.7,1.25,'panel2',border='white')
  for i,col in enumerate(['8B4B23','000000','8B4B23','D4AF37']):rect(s,3.1+i*1.65,3.5,.35,1.25,col)
  line(s,1,4.12,2,4.12,'white',3);line(s,9.7,4.12,11.4,4.12,'white',3);txt(s,d['value'],2,5.4,8.6,.6,33,'white',True,PP_ALIGN.CENTER)
 elif kind=='hand':
  photo(s,'vision',1,.85,2.4,7.1,4)
  for j,t in enumerate(d['labels']):pill(s,t,8.7,2.8+j*1.2,3.2)
 elif kind=='screen':
  if d.get('mode')=='plate':
   frame(s,1.1,2.65,7.4,3.8,'panel');rect(s,1.7,3.65,6.1,1.4,'blue');txt(s,'测试 A01',1.95,3.9,5.6,.85,43,'white',True,PP_ALIGN.CENTER);txt(s,'识别文本\n完整匹配\n通过检测',9.0,3,3.4,2.8,29,'white',True)
  else:
   for j,label in enumerate(['分辨率：看细节','帧率：看时间采样']):
    x=1+j*6.1;frame(s,x,2.6,5.5,3.85,'panel');
    for k in range(4):rect(s,x+.65+k*.98,3.25+(k%2)*.3,.65,.65,'blue',border='white')
    txt(s,label,x+.25,5.55,5,.6,25,'white',True,PP_ALIGN.CENTER)
 elif kind=='plots':
  mode=d.get('mode','growth')
  if mode=='timeline':
   rect(s,1.4,3.4,4,1.3,'blue');rect(s,5.4,3.4,5.8,1.3,'red');txt(s,'模拟等待 20 s',1.6,3.75,3.6,.6,25,'white',True);txt(s,'模拟自动 30 s',5.8,3.75,5,.6,27,'white',True);txt(s,'参数应可配置，按本场规则设定',2,5.55,9.2,.6,27,'white',True,PP_ALIGN.CENTER)
  elif mode=='dance':
   flow(s,['倒计时','前奏动作','关键节点','联动展示']);txt(s,'用实际音轨的时间点来排动作',2,5.7,9.4,.5,26,'white',True,PP_ALIGN.CENTER)
  else:
   flow(s,['现象','原因假设','一次修改','再次验证'])
 else:raise ValueError('Unknown visual kind '+kind)
