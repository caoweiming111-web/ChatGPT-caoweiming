from pathlib import Path
from html.parser import HTMLParser
import json,re,html
R=Path('/workspace/ppt-work/tech-courseware-all')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[]
 def handle_starttag(self,t,a):
  if t in ['br','div','p','h1','h2','h3','h4','li','tr']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['div','p','h1','h2','h3','h4','li','tr']:self.parts.append('\n')
 def handle_data(self,s):self.parts.append(s)
def clean(s):
 p=Text();p.feed(s or '');return '\n'.join(re.sub(r'^[\s*·•⭐⚙✏✅]+','',html.unescape(x)).strip()for x in ''.join(p.parts).splitlines()if x.strip())
D=json.load(open('/workspace/ChatGPT-caoweiming/makex_data.json'));L=[]
for cat,cs in D.items():
 for i,c in enumerate(cs):
  a,b=clean(c.get('objectives')),clean(c.get('procedure'))
  if a and b:
   item={'id':f'{cat}-{i+1:02}','category':cat,'index':i,'name':c['name'],'subtitle':clean(c.get('subtitle')),'equipment':clean(c.get('equipment')),'objectives':a,'procedure':b};L.append(item)
(R/'source-courses.json').write_text(json.dumps(L,ensure_ascii=False,indent=2))
for section,selected in [('robotics',L[:18]),('electronics',[c for c in L if c['id']in ['explorer-23','explorer-24','explorer-25','explorer-26','explorer-27','explorer2-07','explorer2-08','explorer2-09','explorer2-10']]),('camera-cad',[c for c in L if c not in L[:18] and c['category']=='explorer']),('second-year',[c for c in L if c['category']=='explorer2'])]:
 (R/(section+'.txt')).write_text('\n\n'.join('## '+c['id']+' '+c['name']+'\n目标：'+c['objectives']+'\n流程：'+c['procedure']for c in selected))
print('Saved',len(L),'source lessons')
