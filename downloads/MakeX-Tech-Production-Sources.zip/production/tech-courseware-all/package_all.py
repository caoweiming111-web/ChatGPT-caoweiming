from pathlib import Path,PurePosixPath
import json,zipfile,html,urllib.parse,hashlib,math,io
from PIL import Image,ImageDraw,ImageFont
R=Path('/workspace/ppt-work/tech-courseware-all');OUT=R/'output';M=json.load(open(R/'manifest.json'));V=json.load(open(R/'validation-report.json'))
assert V['courses']==49 and V['slides']==675 and not V['issues'] and not V['textOverlapCandidates']
repo_data=Path('/workspace/ChatGPT-caoweiming/makex_data.json');excluded=[]
if repo_data.exists():
 D=json.load(open(repo_data));included={d['id']for d in M}
 for cat,cs in D.items():
  for i,c in enumerate(cs):
   if c.get('name')and f'{cat}-{i+1:02}'not in included:excluded.append({'id':f'{cat}-{i+1:02}','name':c['name'],'reason':'缺少课程目标或具体正文'})
 (R/'excluded-courses.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2))
else:excluded=json.load(open(R/'excluded-courses.json'))
assert len(excluded)==6
# Recover validated manifest if importing the extraction helper refreshed only its source exports.
README='''MakeX 深蓝科技风课件 · 49课 / 675页

1. 这是独立课件包，无需安装或运行任何更新脚本。
2. 双击“课件目录.html”查找课程，或直接打开“PPT课件”文件夹，用 PowerPoint/WPS 打开。
3. “PDF预览”可用浏览器快速查看；讲者备注保留详细讲授提示，完整原教案和核对记录在“教师备课资料”。
4. 第一年的同名课程与第二年的课程分别保留。已有PPT的课程也纳入本次重做。
5. 仅纳入同时有目标与具体正文的49课；缺少内容的5个主题及1个空白占位列在总清单中。
6. 第一年《机器人搭建与编程调试实战课（二）》已按用户确认，依据目标制作AprilTag与Python数据类型，未沿用重复的机械搭建正文。

图片与技术使用说明
- 统一采用深蓝背景、红蓝斜角、红色切角图框、白色大字；每课有对应图解、分步实操与挑战。
- 器材情境图片为AI生成的通用示意，不是指定器材照片、精确装配图或官方赛场图。
- 电路/结构图用于解释原理，不能替代经教师确认的完整接线图与实物尺寸。接口、电压、脚序、角度及加工参数按具体器材和说明校核。
- Python示例已检查语法，但未在真实童芯派/AI Camera上逐一运行；授课前按当前SDK、固件和接线验证。
- 赛事分值、时间和道具尺寸如来自原教案，按课堂案例处理；正式比赛须以对应最新规则和通知复核。
- 未改写现有课程JSON、原附件和原始教案。原教案中的明显单位、科学和逻辑问题在课件/核对备注中修正；原文另存供比对。

检查记录
49份PPT、675页均完成PDF导出和包完整性检查；未检测到中文缺字、文字越界或显著文字标注重叠。19段代码示例通过Python语法解析。
'''
ledger=['# 课程清单与技术核对','','符合条件：49课；合计675页。每课原始目标与正文见独立备课文本。','','|编号|课程|页数|编排与核对说明|','|---|---|---:|---|']
for d in M:ledger.append('|'+d['id']+'|'+d['sourceName']+'|'+str(d['pages'])+'|'+d['notes'].replace('|',' / ').replace('\n',' ')+'|')
ledger+=['','## 未纳入的6项','','|编号|原名称|原因|','|---|---|---|']
for d in excluded:ledger.append('|'+d['id']+'|'+d['name']+'|'+d['reason']+'|')
ledger+=['','## 图像来源','','通用器材情境图为本任务生成。积木截图来自用户上传的《积木转Python·童芯派对照课件》。AprilTag示范使用AprilRobotics公开的36h11编号0–3图案：','https://github.com/AprilRobotics/apriltag-imgs/tree/master/tag36h11','标签族须与实际相机配置匹配；不把AprilTag称作普通二维码。']
LEDGER='\n'.join(ledger)+'\n';(R/'课程清单与技术核对.md').write_text(LEDGER);(R/'使用说明.txt').write_text(README)

CSS='''body{margin:0;background:#020226;color:white;font:16px system-ui,"Microsoft YaHei",sans-serif}header{padding:32px 6%;border-bottom:3px solid #ff343c}h1{font-size:30px}p{line-height:1.7;color:#d6dff2}main{padding:28px 6%;display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:22px}.card{background:#082456;border:1px solid #a52b43;padding:14px}.card img{width:100%;aspect-ratio:16/9;object-fit:cover}h2{font-size:19px;line-height:1.5;min-height:56px}.actions{display:flex;gap:12px;flex-wrap:wrap}a{display:inline-block;color:white;background:#214880;padding:10px 14px;text-decoration:none;border-radius:4px}a.ppt{background:#d52b3c}small{color:#c6d2ed}'''
def q(s):return urllib.parse.quote(s,safe='/')
def catalog(items,title):
 cards=[]
 for d in items:
  stem=Path(d['pptx']).stem;ppt='PPT课件/'+stem+'.pptx';pdf='PDF预览/'+stem+'.pdf';cover='封面/'+d['id']+'.jpg'
  cards.append(f'<article class="card"><img src="{q(cover)}" alt="{html.escape(d["title"])}封面"><small>{d["id"]} · {d["pages"]}页</small><h2>{html.escape(d["title"])}</h2><div class="actions"><a class="ppt" href="{q(ppt)}">打开 PPT</a><a href="{q(pdf)}">PDF 预览</a></div></article>')
 return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(title)+'</title><style>'+CSS+'</style></head><body><header><h1>'+html.escape(title)+'</h1><p>共'+str(len(items))+'课。直接打开PPT，或先查看PDF；无需运行更新脚本。<br>详细讲解见PPT讲者备注，原教案和技术核对见教师备课资料。</p></header><main>'+''.join(cards)+'</main></body></html>'

first=[d for d in M if d['year']=='第一年'];second=[d for d in M if d['year']=='第二年'];assert len(first)==33 and len(second)==16
groups=[('MakeX-Tech-Year1-A','第一年上册',first[:18]),('MakeX-Tech-Year1-B','第一年下册',first[18:]),('MakeX-Tech-Year2','第二年',second)]
packages=[]
for basename,title,items in groups:
 archive=Path('/workspace')/(basename+'.zip');prefix='MakeX_'+title
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  z.writestr(prefix+'/使用说明.txt',README);z.writestr(prefix+'/课件目录.html',catalog(items,'MakeX 科技风课件 · '+title));z.writestr(prefix+'/课程清单与技术核对.md',LEDGER)
  local=[]
  for d in items:
   stem=Path(d['pptx']).stem
   for source,target in [(OUT/d['pptx'],'PPT课件/'+stem+'.pptx'),(OUT/d['pdf'],'PDF预览/'+stem+'.pdf'),(OUT/d['cover'],'封面/'+d['id']+'.jpg'),(OUT/d['reference'],'教师备课资料/'+Path(d['reference']).name)]:z.write(source,prefix+'/'+target)
   local.append({'id':d['id'],'name':d['sourceName'],'pages':d['pages'],'pptx':'PPT课件/'+stem+'.pptx','pdf':'PDF预览/'+stem+'.pdf'})
  z.writestr(prefix+'/manifest.json',json.dumps(local,ensure_ascii=False,indent=2))
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None;names=z.namelist();assert sum(n.endswith('.pptx')for n in names)==len(items);assert sum(n.endswith('.pdf')for n in names)==len(items)
 assert archive.stat().st_size<95*1024**2
 entry={'name':basename,'title':title,'courses':len(items),'slides':sum(d['pages']for d in items),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'path':str(archive)};packages.append(entry);print('PACK',title,len(items),round(entry['bytes']/1024**2,1),'MB',flush=True)

# Seven-page visual catalogue with readable course names and thumbnail covers.
fontpath='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font=ImageFont.truetype(fontpath,28,index=2);heading=ImageFont.truetype(fontpath,50,index=2);small=ImageFont.truetype(fontpath,24,index=2)
pages=[]
for start in range(0,len(M),8):
 im=Image.new('RGB',(1600,2264),'#020226');dr=ImageDraw.Draw(im);dr.text((55,30),'MakeX 科技风课件 · 49课总览',font=heading,fill='white');dr.line((55,105,1545,105),fill='#ff343c',width=5)
 for j,d in enumerate(M[start:start+8]):
  x=55+(j%2)*780;y=145+(j//2)*505;cover=Image.open(OUT/d['cover']).convert('RGB');cover.thumbnail((720,405));dr.rectangle((x-3,y-3,x+723,y+408),outline='#f53642',width=3);im.paste(cover,(x,y));label=d['id']+' · '+d['sourceName'];lines=[label[k:k+28]for k in range(0,len(label),28)]
  for k,t in enumerate(lines[:2]):dr.text((x,y+412+k*36),t,font=font,fill='white')
 dr.text((55,2205),f'{start//8+1} / 7   图片为课堂示意，课件含讲者备注与核对说明',font=small,fill='#c9d4e9');pages.append(im)
preview=Path('/workspace/MakeX-Tech-Course-Catalogue.pdf');pages[0].save(preview,'PDF',save_all=True,append_images=pages[1:],resolution=150)
import fitz
assert len(fitz.open(preview))==7
packages.append({'name':'MakeX-Tech-Course-Catalogue','path':str(preview),'bytes':preview.stat().st_size,'sha256':hashlib.sha256(preview.read_bytes()).hexdigest()})
(R/'delivery-packages.json').write_text(json.dumps(packages,ensure_ascii=False,indent=2));print('All packages verified',flush=True)
