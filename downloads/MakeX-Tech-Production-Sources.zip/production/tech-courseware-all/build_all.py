from pathlib import Path
from copy import deepcopy
from collections import Counter
import json,re,ast,math,shutil,hashlib
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.enum.text import PP_ALIGN
from PIL import Image
import visuals as V
from blueprints import B
R=Path('/workspace/ppt-work/tech-courseware-all');OUT=R/'output';OUT.mkdir(exist_ok=True)
SOURCES=json.load(open(R/'source-courses.json'));S={c['id']:c for c in SOURCES};MAN=[];CODES=[]

def title_clean(t):return t.replace('AI C amera','AI Camera').replace('onshape','Onshape').replace('童心派','童芯派').replace('\ufffd','')
def display_title(c):
 t=title_clean(c['name']);return t

def notes(c,spec,title,extra=''):
 # Use source excerpts for instructor reference without copying dense prose onto slides.
 source=c['objectives'] if c['id']=='explorer-16' else c['procedure'];paras=[x.strip()for x in source.splitlines()if len(x.strip())>12]
 grams=lambda t:set(t[i:i+2]for i in range(len(t)-1))
 query=grams(title)
 selected=sorted(paras,key=lambda p:len(grams(p)&query),reverse=True)[:2]
 return '\n\n'.join(x for x in [f"{c['id']}｜{c['name']}\n本页：{title}",extra,'讲授提示：先让学生观察图或预测结果，再解释原理，最后用一次可检查的任务验证。','原教案相关参考：\n'+'\n'.join(selected), '制作与技术核对：'+spec['notes']]if x)

def new_slide(prs,c,spec,title,caption='',kicker=''):
 s=prs.slides.add_slide(prs.slide_layouts[6]);V.bg(s)
 V.txt(s,kicker or c['id'].upper(),.78,.28,11.8,.3,11,'red',True)
 V.txt(s,title,.78,.78,11.8,1.05,31,'white',True)
 V.line(s,.78,1.92,5.0,1.92,'red',2.5)
 if caption:V.txt(s,caption,.8,2.07,11.7,.43,17,'muted')
 V.line(s,.78,6.94,12.55,6.94,'panel2',1)
 V.txt(s,('Explorer 第一年'if c['category']=='explorer'else'Explorer 第二年')+' · '+c['id'],.78,7.12,9,.22,10,'muted')
 V.txt(s,f'{len(prs.slides):02}',12.05,7.03,.5,.35,14,'white',True,PP_ALIGN.RIGHT)
 s.notes_slide.notes_text_frame.text=notes(c,spec,title)
 return s

def body_foot(s,t='课堂示意 · 参数与接口按实物校核'):
 V.txt(s,t,.8,6.64,11.6,.21,9,'muted')

def cover(prs,c,spec):
 s=prs.slides.add_slide(prs.slide_layouts[6]);V.bg(s);V.frame(s,1.0,.9,11.3,5.85,'panel','red',.3)
 V.txt(s,'MakeX Explorer',1.65,1.45,5.9,.6,32,'white',True)
 V.line(s,1.65,2.28,6.3,2.28,'red',3)
 V.txt(s,display_title(c),1.65,2.7,5.35,2.7,32,'white',True)
 V.pill(s,('第一年'if c['category']=='explorer'else'第二年')+' · '+c['id'],1.65,5.76,4.75,'panel2')
 V.photo(s,*spec['asset'],7.45,1.65,4.1,4.25)
 V.txt(s,'AI 器材情境示意 · 非指定产品或接线依据',7.45,6.14,4.1,.3,9,'muted')
 s.notes_slide.notes_text_frame.text=notes(c,spec,'封面','课程副标题：'+c['subtitle']+'\n器材：'+c['equipment']+'\n本课目标：\n'+c['objectives'])

def agenda(prs,c,spec):
 s=new_slide(prs,c,spec,'今天，我们一起解决三个问题',kicker='LEARNING QUESTIONS')
 for i,q in enumerate(spec['questions']):
  y=2.55+i*1.28;V.txt(s,f'{i+1:02}',1.02,y,1.0,.73,43,'white',True);V.txt(s,q,2.65,y+.08,9.5,.78,28,'white',True)

def mission(prs,c,spec):
 s=new_slide(prs,c,spec,'下课前，用作品证明你做到了','用演示、测量或记录回答。')
 V.photo(s,*spec['asset'],.95,2.8,6.6,3.55)
 for i,t in enumerate(spec['goals']):
  y=2.85+i*1.13;V.txt(s,f'{i+1:02}',8.05,y,.65,.65,31,'red',True);V.txt(s,t,9.05,y+.04,3.25,.87,25,'white',True)
 body_foot(s,'器材情境插画 · 学习目标以实际作品验证')
 s.notes_slide.notes_text_frame.text='原始完整课程目标：\n'+c['objectives']+'\n\n可检查成果：\n'+'\n'.join(spec['goals'])+'\n\n器材：'+c['equipment']+'\n\n'+spec['notes']

def _fit_picture(s,path,x,y,w,h):
 im=Image.open(path);a=im.width/im.height
 if w/h>a:ww=h*a;hh=h
 else:ww=w;hh=w/a
 xx=x+(w-ww)/2;yy=y+(h-hh)/2
 V.rect(s,x,y,w,h,'white');s.shapes.add_picture(str(path),Inches(xx),Inches(yy),width=Inches(ww),height=Inches(hh))

def code_visual(s,visual,asset):
 table={'blocks_servo':'p4-1.png','blocks_event':'p6-1.png','blocks_wait':'p7-1.png','blocks_loop':'p8-1.png','blocks_timer':'p11-1.png','blocks_led':'p12-1.png'}
 if visual=='blocks_import':
  V.frame(s,.9,2.8,4.3,3.55,'panel')
  for i,t in enumerate(['event：事件','time：时间','cyberpi：主控','mbot2：扩展']):V.txt(s,t,1.2,3.05+i*.7,3.7,.5,24,'white',True)
 elif visual in table:
  V.frame(s,.9,2.8,4.3,3.55,'white','red');_fit_picture(s,Path('/workspace/ppt-work/template-study')/table[visual],1.0,2.9,4.1,3.35)
 elif visual in ['tag','coordinate']:
  V.frame(s,.9,2.8,4.3,3.55,'panel');V.tag(s,0,1.7,3.3,2.45)
 elif visual=='servo':
  V.frame(s,.9,2.8,4.3,3.55,'panel');V.robot(s,1.65,3.5,1.3);V.txt(s,'先确认安全角度',1.1,5.7,3.9,.4,21,'white',True,PP_ALIGN.CENTER)
 elif visual=='line':
  V.frame(s,.9,2.8,4.3,3.55,'panel');V.rect(s,1.3,3.4,3.5,2.0,'white');V.line(s,2.7,3.55,3.1,5.1,'black',12);V.txt(s,'先判有效，再运算',1.1,5.7,3.9,.4,21,'white',True,PP_ALIGN.CENTER)
 elif visual=='barrier':
  V.frame(s,.9,2.8,4.3,3.55,'panel');V.rect(s,1.7,3.8,.55,1.8,'blue');a=V.rect(s,2,3.7,2.3,.25,'red');a.rotation=-20;V.txt(s,'完整名单匹配',1.1,5.7,3.9,.4,21,'white',True,PP_ALIGN.CENTER)
 else:
  V.frame(s,.9,2.8,4.3,3.55,'panel');V.txt(s,'观察\n预测\n验证',1.4,3.1,3.3,2.8,33,'white',True,PP_ALIGN.CENTER)

def topic(prs,c,spec,d,n):
 s=new_slide(prs,c,spec,d['title'],d.get('caption',''),kicker=f'核心探究 / {n:02}')
 if d['kind']=='code':
  ast.parse(d['code']);CODES.append({'course':c['id'],'title':d['title'],'code':d['code']})
  code_visual(s,d.get('visual',''),spec['asset']);V.frame(s,5.5,2.8,6.9,3.55,'panel2','blue')
  longest=max(len(x)for x in d['code'].splitlines());size=min(18,6.45*72/max(1,longest)/.62)
  V.txt(s,d['code'],5.75,3.02,6.4,3.1,size,'white',False,font='DejaVu Sans Mono',wrap=False)
  body_foot(s,'代码/逻辑示例 · 课堂前按当前SDK、固件与接线验证')
 else:
  V.draw_scene(s,d,spec['asset']);body_foot(s,'AprilTag 36h11 示例 · 来源 AprilRobotics'if d['kind']=='tag'else'课堂示意 · 参数、方向与接口按实物校核')
 s.notes_slide.notes_text_frame.text=notes(c,spec,d['title'],d.get('caption','')+'\n本页图示用于解释原理，不是保证可直接照接的完整装配/接线图。\n'+d.get('teacher',''))


def practice(prs,c,spec):
 s=new_slide(prs,c,spec,'轮到你来完成一次','先单独验证，再组合动作或完整装配。',kicker='动手实践')
 V.photo(s,*spec['asset'],.95,2.8,6.6,3.55)
 for i,t in enumerate(spec['practice']):
  y=2.83+i*1.15;V.txt(s,str(i+1),8.05,y,.65,.6,34,'red',True);V.txt(s,t,9.0,y+.02,3.3,.92,24,'white',True)
 body_foot(s,'器材情境示意 · 具体操作由教师按设备与材料确认')
 s.notes_slide.notes_text_frame.text=notes(c,spec,'课堂实践','\n'.join(f'{i+1}. {t}'for i,t in enumerate(spec['practice']))+'\n要求每一步都留下能核对的显示、测量、截图或作品证据。')

def troubleshoot(prs,c,spec):
 s=new_slide(prs,c,spec,'遇到这个现象，你先查哪里？','先描述现象，再选择一个检查方向。',kicker='调试与判断')
 for i,(problem,check)in enumerate(spec['checks']):
  y=2.78+i*1.14;V.frame(s,.95,y,4.85,.91,'panel');V.txt(s,problem,1.17,y+.16,4.4,.6,23,'white',True);V.line(s,5.95,y+.46,6.45,y+.46,'red',2,True);V.frame(s,6.62,y,5.76,.91,'panel2');V.txt(s,check,6.85,y+.15,5.3,.63,22,'white',True)
 body_foot(s)
 s.notes_slide.notes_text_frame.text=notes(c,spec,'故障排查','不要同时改动多个条件。先让学生说明依据，再检查线路、软件状态或装配基准。\n'+'\n'.join(a+' → '+b for a,b in spec['checks']))

def challenge(prs,c,spec):
 s=new_slide(prs,c,spec,'完成挑战，还要说明你的依据','不只展示“成功了”，也展示怎样验证。',kicker='综合挑战')
 V.frame(s,1.0,2.8,11.35,1.7,'panel');V.txt(s,spec['challenge'],1.35,3.05,10.65,1.2,29,'white',True)
 for i,t in enumerate(['作品 / 演示','测量 / 记录','解释 / 改进']):V.node(s,t,1.0+i*3.9,5.1,3.55,1.02)
 body_foot(s)
 s.notes_slide.notes_text_frame.text=notes(c,spec,'综合挑战',spec['challenge']+'\n教师从成果、依据和解释三个维度核对原始目标，不以速度或一次偶然成功替代完成质量。')

def exit_slide(prs,c,spec):
 s=new_slide(prs,c,spec,'用三句话，留下今天的收获',kicker='复盘与保存')
 for i,t in enumerate(['我观察到……','我能解释……','下次我会……']):
  y=2.8+i*1.11;V.frame(s,1.0,y,7.0,.85,'panel');V.txt(s,t,1.3,y+.18,6.4,.5,28,'white',True)
 V.txt(s,'保存程序 / 模型\n保留测量与截图\n整理器材与桌面',8.7,3.0,3.5,2.8,24,'muted')
 s.notes_slide.notes_text_frame.text=notes(c,spec,'复盘','回到课程目标逐项核对。请学生保存当前程序或源模型，并记录具体版本。教师可从随课“教案与核对”文本查看原始目标与正文。')

def build():
 for c in SOURCES:
  id=c['id'];year='第一年'if c['category']=='explorer'else'第二年';folder=OUT/year;folder.mkdir(exist_ok=True)
  fname=id+'_'+re.sub(r'[<>:"/\\|?*]','_',display_title(c))[:42]
  dest=folder/(fname+'.pptx')
  if id=='explorer-01':
   shutil.copyfile('/workspace/ppt-work/explorer-intro-tech-v2/MakeX-Explorer-2026-TechStyle-v2.pptx',dest);spec={'notes':'沿用已经确认的18页深蓝科技风样稿。'};pagecount=18
  else:
   spec=B[id];prs=Presentation();prs.slide_width=Inches(13.333333);prs.slide_height=Inches(7.5)
   cover(prs,c,spec);agenda(prs,c,spec);mission(prs,c,spec)
   for i,d in enumerate(spec['topics'],1):topic(prs,c,spec,d,i)
   practice(prs,c,spec);troubleshoot(prs,c,spec);challenge(prs,c,spec);exit_slide(prs,c,spec)
   prs.save(dest);pagecount=len(prs.slides)
  reference=folder/(fname+'_教案与核对.txt')
  reference.write_text('课程：'+c['name']+'\n编号：'+id+'\n\n原始完整目标：\n'+c['objectives']+'\n\n原始教案正文（原文保留备查）：\n'+c['procedure']+'\n\n本次编排与技术核对：\n'+spec['notes']+'\n\n图片说明：情境照片为AI生成的通用教学示意，不是指定器材产品照；接口、尺寸、元件脚序按实物说明校核。原理图用于讲解，不能代替经教师验证的完整接线图。')
  entry={'id':id,'sourceName':c['name'],'title':display_title(c),'year':year,'pptx':str(dest.relative_to(OUT)),'reference':str(reference.relative_to(OUT)),'pages':pagecount,'notes':spec['notes'],'sourceSHA256':hashlib.sha256((c['objectives']+'\n'+c['procedure']).encode()).hexdigest()};MAN.append(entry);print(id,pagecount,flush=True)
 (R/'manifest.json').write_text(json.dumps(MAN,ensure_ascii=False,indent=2));(R/'code-snippets.json').write_text(json.dumps(CODES,ensure_ascii=False,indent=2));(R/'text-layout-audit.json').write_text(json.dumps(V.TEXT_AUDIT,ensure_ascii=False,indent=2))
 print('TOTAL',len(MAN),'decks',sum(x['pages']for x in MAN),'pages',len(CODES),'syntax-checked code snippets',flush=True)
if __name__=='__main__':build()
