from pathlib import Path
from collections import Counter
import json,re,zipfile,ast,shutil,hashlib,math
import fitz
from pptx import Presentation
from PIL import Image,ImageDraw
R=Path('/workspace/ppt-work/tech-courseware-all');OUT=R/'output';M=json.load(open(R/'manifest.json'));S=json.load(open(R/'source-courses.json'))
assert {x['id']for x in M}=={x['id']for x in S} and len(M)==49
issues=[];candidates=[];pages=0;image_placements=0
sheets=R/'review';sheets.mkdir(exist_ok=True)
for d in M:
 ppt=OUT/d['pptx'];pdf=R/'pdf'/(ppt.stem+'.pdf')
 with zipfile.ZipFile(ppt)as z:assert z.testzip()is None
 prs=Presentation(ppt);doc=fitz.open(pdf);assert len(prs.slides)==len(doc)==d['pages'],d['id'];pages+=len(doc)
 assert sum(sh.shape_type==13 for s in prs.slides for sh in s.shapes)>=3,d['id']
 thumbnails=[]
 for i,(s,page)in enumerate(zip(prs.slides,doc),1):
  image_placements+=sum(sh.shape_type==13 for sh in s.shapes)
  assert len(s.notes_slide.notes_text_frame.text)>50,(d['id'],i)
  source=''.join(sh.text for sh in s.shapes if sh.has_text_frame)
  missing=Counter(re.findall('[\u4e00-\u9fff]',source))-Counter(re.findall('[\u4e00-\u9fff]',page.get_text()))
  if missing:issues.append({'id':d['id'],'page':i,'type':'missing CJK','detail':dict(missing)})
  if '\ufffd'in source:issues.append({'id':d['id'],'page':i,'type':'replacement character'})
  spans=[]
  for b in page.get_text('dict')['blocks']:
   for ln in b.get('lines',[]):
    for sp in ln['spans']:
     x0,y0,x1,y1=sp['bbox']
     if x0<-.5 or y0<-.5 or x1>page.rect.width+1 or y1>page.rect.height+1:issues.append({'id':d['id'],'page':i,'type':'text outside canvas','text':sp['text'],'bbox':sp['bbox']})
     if len(sp['text'].strip())>1 and sp['size']>=15:spans.append(sp)
  for a in range(len(spans)):
   for b in range(a+1,len(spans)):
    aa,bb=spans[a],spans[b];ra,rb=fitz.Rect(aa['bbox']),fitz.Rect(bb['bbox']);inter=ra&rb
    if inter.get_area()>.28*min(ra.get_area(),rb.get_area()):candidates.append({'id':d['id'],'page':i,'a':aa['text'],'b':bb['text']})
  pix=page.get_pixmap(matrix=fitz.Matrix(.42,.42),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((395,225));thumbnails.append(im)
 cols=4;rows=math.ceil(len(thumbnails)/cols);sheet=Image.new('RGB',(1600,rows*245),'#ccd2dd');draw=ImageDraw.Draw(sheet)
 for j,im in enumerate(thumbnails):
  x=(j%cols)*400;y=(j//cols)*245;sheet.paste(im,(x,y));draw.text((x+8,y+225),d['id']+' / '+str(j+1),fill='black')
 sheet.save(sheets/(d['id']+'.jpg'),quality=88)
 cover=doc[0].get_pixmap(matrix=fitz.Matrix(.55,.55),alpha=False);thumbdir=OUT/d['year']/'预览封面';thumbdir.mkdir(exist_ok=True);cover.save(thumbdir/(d['id']+'.jpg'))
 dest=OUT/d['year']/'PDF预览';dest.mkdir(exist_ok=True);shutil.copyfile(pdf,dest/pdf.name);d['pdf']=str((dest/pdf.name).relative_to(OUT));d['cover']=str((thumbdir/(d['id']+'.jpg')).relative_to(OUT));d['sha256']=hashlib.sha256(ppt.read_bytes()).hexdigest()
 print('Checked',d['id'],len(doc),'pages',flush=True)
for x in json.load(open(R/'code-snippets.json')):ast.parse(x['code'])
report={'courses':len(M),'slides':pages,'picturePlacements':image_placements,'codeSnippetsSyntaxChecked':len(json.load(open(R/'code-snippets.json'))),'issues':issues,'textOverlapCandidates':candidates,'hardwareTested':False}
(R/'validation-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(R/'manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2))
print('REPORT',len(M),'courses',pages,'slides; issues',len(issues),'overlap candidates',len(candidates),flush=True)
if issues:raise SystemExit(1)
