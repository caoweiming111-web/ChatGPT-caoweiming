from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,json
R=Path('/workspace/ppt-work/tech-courseware-all');OUT=R/'output';PDF=R/'pdf';PDF.mkdir(exist_ok=True);M=json.load(open(R/'manifest.json'))
def batch(k,items):
 cmd=['soffice',f'-env:UserInstallation=file:///tmp/makex-all-tech-{k}','--headless','--convert-to','pdf','--outdir',str(PDF)]+[str(OUT/x['pptx'])for x in items]
 with open(R/f'office-{k}.log','w')as log:
  result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 if result.returncode:raise RuntimeError(f'Office batch{k} exit {result.returncode}')
 for d in items:
  p=PDF/(Path(d['pptx']).stem+'.pdf')
  if not p.exists()or p.stat().st_size<1000:raise RuntimeError('Missing PDF '+d['id'])
 return k,len(items)
with ThreadPoolExecutor(max_workers=4)as pool:
 jobs=[pool.submit(batch,k,M[k::4])for k in range(4)]
 for job in as_completed(jobs):print('Rendered batch',*job.result(),flush=True)
print('All',len(M),'PDFs rendered',flush=True)
