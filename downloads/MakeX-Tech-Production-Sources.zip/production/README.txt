课件制作源文件与核对记录。
依赖：Python、python-pptx、Pillow、PyMuPDF、LibreOffice、Noto CJK字体。
脚本中的原工作路径为 /workspace/ppt-work/tech-courseware-all，使用前需在独立工作目录调整路径；不要覆盖现有课程数据。
流程：build_all.py → render_all.py → validate_all.py → package_all.py。
source-courses.json已保存49课全部输入，excluded-courses.json保存未纳入项；extract_courses.py仅供从原项目重新提取，不是复现必须步骤。
完整49份课件与PDF已另行分成三个下载包，此包仅用于留存制作来源与继续修改。
