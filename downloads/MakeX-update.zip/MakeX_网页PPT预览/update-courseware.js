'use strict';
// Merge ONLY generated attachments into an existing installation. Never replace lesson content.
const fs=require('node:fs');const path=require('node:path');
function update(target){
 const root=__dirname;
 if(typeof target!=='string'||!target.trim())throw Error('尚未选择旧版 MakeX 文件夹，未更新任何文件。');
 target=target.trim();
 if(target.startsWith('"')&&target.endsWith('"'))target=target.slice(1,-1);
 if(!target.trim())throw Error('尚未选择旧版 MakeX 文件夹，未更新任何文件。');
 target=path.resolve(target);
 if(fs.existsSync(target)&&fs.statSync(target).isFile()&&['启动MakeX.bat','server.js'].includes(path.basename(target)))target=path.dirname(target);
 if(target===root)throw Error('请选择旧版 MakeX 所在文件夹，不能选择更新包自身。');
 const dataFile=path.join(target,'makex_data.json');if(!fs.existsSync(dataFile)||!fs.existsSync(path.join(target,'server.js')))throw Error('所选目录不是 MakeX 程序目录，未更新任何文件。');
 const source=JSON.parse(fs.readFileSync(path.join(root,'makex_data.json'),'utf8').replace(/^\uFEFF/,''));
 const current=JSON.parse(fs.readFileSync(dataFile,'utf8').replace(/^\uFEFF/,''));
 for(const k of ['inspire','explorer','explorer2','challenge'])if(!Array.isArray(current[k]))throw Error('原课程文件格式异常，未更新。');
 const added=[];const unmatched=[];
 for(const [cat,courses]of Object.entries(source))for(const c of courses){
  const newPpts=(c.ppts||[]).filter(p=>p.generated);if(!newPpts.length)continue;
  const matches=current[cat].filter(old=>old.name===c.name);
  if(matches.length!==1){unmatched.push(c.name);continue;}
  const old=matches[0];old.ppts=old.ppts||[];
  for(const p of newPpts)if(!old.ppts.some(x=>x.path===p.path||x.previewId===p.previewId)){old.ppts.push(p);added.push(c.name);}
 }
 const files=['index.html','server.js','ppt-preview.js','ppt-viewer.html','ppt-viewer.js','sync-courses.js','managed-git-sync.js','course-preview.js','course-images.js','school-knowledge.js','git-sync-client.js','check-local-server.js','启动MakeX.bat','start-server.bat'];
 for(const file of files)if(!fs.existsSync(path.join(root,file)))throw Error('更新包不完整：'+file);
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'ppt-previews/index.json'),'utf8'));for(const d of manifest.decks){if(!fs.existsSync(path.join(root,d.file)))throw Error('课件缺失：'+d.file);for(const s of d.slides)if(!fs.existsSync(path.join(root,s)))throw Error('预览缺失：'+s);}
 const backup=path.join(target,'.makex-backups','courseware-'+new Date().toISOString().replace(/[:.]/g,'-'));fs.mkdirSync(backup,{recursive:true});
 for(const file of [...files,'makex_data.json'])if(fs.existsSync(path.join(target,file)))fs.copyFileSync(path.join(target,file),path.join(backup,file));
 // Back up potentially overwritten generated assets too, preserving local customizations.
 for(const folder of ['ppt','ppt-previews'])if(fs.existsSync(path.join(target,folder)))fs.cpSync(path.join(target,folder),path.join(backup,folder),{recursive:true});
 for(const file of files)fs.copyFileSync(path.join(root,file),path.join(target,file));
 for(const folder of ['ppt','ppt-previews'])fs.cpSync(path.join(root,folder),path.join(target,folder),{recursive:true});
 const tmp=dataFile+'.courseware.tmp';fs.writeFileSync(tmp,JSON.stringify(current,null,2),'utf8');fs.renameSync(tmp,dataFile);
 const report={added:added.length,unmatched,backup};fs.writeFileSync(path.join(backup,'更新记录.json'),JSON.stringify(report,null,2));return report;
}
function selectTarget({platform=process.platform,run=require('node:child_process').execFileSync,input=process.stdin,output=process.stdout}={}){
 if(platform==='win32'){
  const script=`[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Select your OLD MakeX folder (contains server.js and makex_data.json)'
$dialog.ShowNewFolderButton = $false
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.SelectedPath) }
$dialog.Dispose()`;
  try{
   const encoded=Buffer.from(script,'utf16le').toString('base64');
   const result=run('powershell.exe',['-NoProfile','-STA','-EncodedCommand',encoded],{encoding:'utf8',windowsHide:true,timeout:300000});
   return Promise.resolve(result.replace(/^\uFEFF/,'').trim());
  }catch{
   output.write('无法打开文件夹选择窗口，请在下方输入旧版 MakeX 的文件夹路径。\n');
  }
 }
 return new Promise(resolve=>{
  const rl=require('node:readline').createInterface({input,output});
  rl.once('close',()=>resolve(''));
  rl.question('请输入旧版 MakeX 文件夹路径（可拖入文件夹后按回车）：',answer=>{resolve(answer);rl.close();});
 });
}
async function main(){
 try{
  let target=process.argv[2];
  if(target==='--interactive'||!target){
   console.log('请先在旧网页保存课程，并关闭旧的 MakeX 服务器窗口。');
   console.log('请选择原来含有“启动MakeX.bat”和 makex_data.json 的旧程序文件夹。');
   target=await selectTarget();
   if(!target){console.log('已取消，未更新任何文件。');return;}
  }
  const r=update(target);
  console.log('更新完成，追加课件记录：'+r.added+'。\n原文件备份：'+r.backup);
  if(r.unmatched.length)console.log('以下课程因已改名、已删除或重名，未自动匹配：\n'+r.unmatched.join('\n'));
  console.log('请重新运行旧目录中的 启动MakeX.bat。浏览器提示数据不一致时，先备份浏览器课程，再读取项目文件。');
 }catch(e){console.error('更新失败：'+e.message);process.exitCode=1;}
}
if(require.main===module)main();
module.exports={update,selectTarget};
