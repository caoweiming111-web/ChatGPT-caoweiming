'use strict';
// Merge ONLY generated attachments into an existing installation. Never replace lesson content.
const fs=require('node:fs');const path=require('node:path');
function update(target){
 const root=__dirname;target=path.resolve(target||'');
 if(!target||target===root)throw Error('请选择旧版 MakeX 所在文件夹，不能选择更新包自身。');
 const dataFile=path.join(target,'makex_data.json');if(!fs.existsSync(dataFile)||!fs.existsSync(path.join(target,'server.js')))throw Error('所选目录不是 MakeX 程序目录，未更新任何文件。');
 const source=JSON.parse(fs.readFileSync(path.join(root,'makex_data.json'),'utf8').replace(/^\uFEFF/,''));
 const current=JSON.parse(fs.readFileSync(dataFile,'utf8').replace(/^\uFEFF/,''));
 for(const k of ['inspire','explorer','explorer2','challenge'])if(!Array.isArray(current[k]))throw Error('原课程文件格式异常，未更新。');
 const added=[];const unmatched=[];
 for(const [cat,courses]of Object.entries(source))for(const c of courses){
  const newPpts=(c.ppts||[]).filter(p=>p.generated);if(!newPpts.length)continue;
  const matches=current[cat].filter(old=>old.name===c.name);
  if(matches.length!==1){unmatched.push(c.name);continue;}
  const old=matches[0];old.ppts=old.ppts||[];
  for(const p of newPpts)if(!old.ppts.some(x=>x.path===p.path||x.previewId===p.previewId)){old.ppts.push(p);added.push(c.name);}
 }
 const files=['index.html','server.js','ppt-preview.js','ppt-viewer.html','ppt-viewer.js','sync-courses.js','managed-git-sync.js','course-preview.js','course-images.js','school-knowledge.js','git-sync-client.js','check-local-server.js','启动MakeX.bat','start-server.bat'];
 for(const file of files)if(!fs.existsSync(path.join(root,file)))throw Error('更新包不完整：'+file);
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'ppt-previews/index.json'),'utf8'));for(const d of manifest.decks){if(!fs.existsSync(path.join(root,d.file)))throw Error('课件缺失：'+d.file);for(const s of d.slides)if(!fs.existsSync(path.join(root,s)))throw Error('预览缺失：'+s);}
 const backup=path.join(target,'.makex-backups','courseware-'+new Date().toISOString().replace(/[:.]/g,'-'));fs.mkdirSync(backup,{recursive:true});
 for(const file of [...files,'makex_data.json'])if(fs.existsSync(path.join(target,file)))fs.copyFileSync(path.join(target,file),path.join(backup,file));
 // Back up potentially overwritten generated assets too, preserving local customizations.
 for(const folder of ['ppt','ppt-previews'])if(fs.existsSync(path.join(target,folder)))fs.cpSync(path.join(target,folder),path.join(backup,folder),{recursive:true});
 for(const file of files)fs.copyFileSync(path.join(root,file),path.join(target,file));
 for(const folder of ['ppt','ppt-previews'])fs.cpSync(path.join(root,folder),path.join(target,folder),{recursive:true});
 const tmp=dataFile+'.courseware.tmp';fs.writeFileSync(tmp,JSON.stringify(current,null,2),'utf8');fs.renameSync(tmp,dataFile);
 const report={added:added.length,unmatched,backup};fs.writeFileSync(path.join(backup,'更新记录.json'),JSON.stringify(report,null,2));return report;
}
if(require.main===module){try{const r=update(process.argv[2]);console.log('更新完成，追加课件记录：'+r.added+'。\n原文件备份：'+r.backup);if(r.unmatched.length)console.log('以下课程因已改名、已删除或重名，未自动匹配：\n'+r.unmatched.join('\n'));console.log('请重新运行旧目录中的 启动MakeX.bat。浏览器提示数据不一致时，先备份浏览器课程，再读取项目文件。');}catch(e){console.error('更新失败：'+e.message);process.exitCode=1;}}
module.exports={update};
