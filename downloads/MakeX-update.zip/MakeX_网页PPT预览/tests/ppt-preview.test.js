'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const fsp=require('node:fs/promises');const path=require('node:path');const os=require('node:os');const http=require('node:http');const {once}=require('node:events');
const {inside,handle}=require('../ppt-preview');const root=path.join(__dirname,'..');
test('every authored courseware entry has a valid PPTX and a complete, ordered preview',()=>{
 const data=JSON.parse(fs.readFileSync(path.join(root,'makex_data.json'),'utf8'));const m=JSON.parse(fs.readFileSync(path.join(root,'ppt-previews/index.json'),'utf8'));
 assert.equal(m.decks.length,40);assert.equal(m.decks.filter(d=>d.draft).length,5);const ids=new Set();
 for(const d of m.decks){assert.ok(!ids.has(d.id));ids.add(d.id);const course=data[d.category][d.index];assert.ok(course.ppts.some(p=>p.path===d.file&&p.previewId===d.id));assert.equal(fs.readFileSync(path.join(root,d.file)).subarray(0,2).toString(),'PK');assert.equal(d.slides.length,d.pages);assert.ok(d.pages>=7);for(const [i,p]of d.slides.entries()){assert.equal(p,`ppt-previews/${d.id}/${String(i+1).padStart(3,'0')}.jpg`);const jpg=fs.readFileSync(path.join(root,p));assert.equal(jpg.readUInt16BE(),0xffd8);}}
 for(const courses of Object.values(data))for(const c of courses){if(c.name&&!/^新课程\s*\d+$/.test(c.name))assert.ok((c.ppts||[]).some(p=>/\.pptx?$/i.test(p.name)),c.name);}
});
test('preview file resolution rejects traversal, missing paths and escaping symlinks',async t=>{
 const dir=await fsp.mkdtemp(path.join(os.tmpdir(),'makex-path-'));t.after(()=>fsp.rm(dir,{recursive:true,force:true}));await fsp.mkdir(path.join(dir,'safe'));await fsp.writeFile(path.join(dir,'safe','a.txt'),'safe');await fsp.writeFile(path.join(dir,'secret.txt'),'secret');await fsp.symlink(path.join(dir,'secret.txt'),path.join(dir,'safe','link'));
 assert.ok(inside(path.join(dir,'safe'),'a.txt'));for(const p of ['../secret.txt','..\\secret.txt','link','missing','a\0.txt','/etc/passwd'])assert.equal(inside(path.join(dir,'safe'),p),null,p);
});
test('preview HTTP serves assets and PPT bytes and rejects unauthorized or missing conversions',async t=>{
 const server=http.createServer((req,res)=>{const local=req.headers['x-test-local']==='1';handle(req,res,root,local).then(handled=>{if(!handled){res.writeHead(404);res.end();}}).catch(e=>{res.writeHead(500);res.end(e.message);});});server.listen(0,'127.0.0.1');await once(server,'listening');t.after(()=>new Promise(r=>server.close(r)));const base='http://127.0.0.1:'+server.address().port;
 const m=await(await fetch(base+'/ppt-previews/index.json')).json();const d=m.decks[0];for(const p of ['ppt-viewer.html','ppt-viewer.js',d.file,d.slides[0]]){const r=await fetch(base+'/'+p.split('/').map(encodeURIComponent).join('/'));assert.equal(r.status,200,p);assert.ok((await r.arrayBuffer()).byteLength>100);}
 assert.equal((await fetch(base+'/ppt-preview/convert?file='+encodeURIComponent(d.file),{method:'POST',headers:{'X-MakeX-Preview':'1'}})).status,403);
 assert.equal((await fetch(base+'/ppt-preview/convert?file=ppt/missing.pptx',{method:'POST',headers:{'X-MakeX-Preview':'1','X-Test-Local':'1'}})).status,404);
 assert.equal((await fetch(base+'/ppt/missing.pptx')).status,404);
 assert.equal((await fetch(base+'/ppt/ppt-preview.js')).status,404);
});
test('local updater preserves existing lesson edits and attachments and is repeatable',async t=>{
 const {update}=require('../update-courseware');const dir=await fsp.mkdtemp(path.join(os.tmpdir(),'makex-update-'));t.after(()=>fsp.rm(dir,{recursive:true,force:true}));
 const current=JSON.parse(fs.readFileSync(path.join(root,'makex_data.json'),'utf8'));
 for(const courses of Object.values(current))for(const c of courses)c.ppts=(c.ppts||[]).filter(p=>!p.generated);
 current.explorer[0].objectives='教师本机修改的目标，不得覆盖';current.explorer[0].ppts.push({name:'自有附件.pptx',path:'E:/ppt/自有附件.pptx'});
 await fsp.writeFile(path.join(dir,'makex_data.json'),JSON.stringify(current));await fsp.writeFile(path.join(dir,'server.js'),'// old server');
 const first=update(dir);assert.equal(first.added,40);const saved=JSON.parse(fs.readFileSync(path.join(dir,'makex_data.json'),'utf8'));assert.equal(saved.explorer[0].objectives,current.explorer[0].objectives);assert.deepEqual(saved.explorer[0].ppts[0],current.explorer[0].ppts[0]);assert.equal(fs.readFileSync(path.join(first.backup,'server.js'),'utf8'),'// old server');
 const removeGenerated=d=>{for(const courses of Object.values(d))for(const c of courses)c.ppts=(c.ppts||[]).filter(p=>!p.generated);return d;};assert.deepEqual(removeGenerated(structuredClone(saved)),current);
 const second=update(dir);assert.equal(second.added,0);assert.deepEqual(JSON.parse(fs.readFileSync(path.join(dir,'makex_data.json'),'utf8')),saved);
});
