'use strict';
// Local-only conversion. Prebuilt previews need no installed office application.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const run = promisify(execFile);
const MIME = {'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.json':'application/json;charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.pdf':'application/pdf','.pptx':'application/vnd.openxmlformats-officedocument.presentationml.presentation','.ppt':'application/vnd.ms-powerpoint'};
function inside(root, relative) {
  if (typeof relative !== 'string' || relative.includes('\0') || relative.includes('\\') || relative.split('/').some(p => p === '..' || p === '.')) return null;
  const resolved = path.resolve(root, relative);
  if (!resolved.startsWith(path.resolve(root) + path.sep)) return null;
  try { const real = fs.realpathSync(resolved); const base = fs.realpathSync(root); return real.startsWith(base + path.sep) ? real : null; } catch { return null; }
}
function findPpt(root, file) {
  if (typeof file !== 'string' || !/\.pptx?$/i.test(file)) return null;
  if (file.startsWith('ppt/')) return inside(path.join(root, 'ppt'), file.slice(4));
  // Legacy attachments are served only below the configured PPT directory.
  return inside(process.env.MAKEX_PPT_ROOT || 'E:/ppt', file);
}
function json(res, status, data) { res.writeHead(status, {'Content-Type':'application/json;charset=utf-8','Cache-Control':'no-store'}); res.end(JSON.stringify(data)); }
function serve(req, res, file) {
  if (!file || !fs.statSync(file).isFile()) { res.writeHead(404); res.end('File not found'); return; }
  const stat=fs.statSync(file);
  res.writeHead(200, {'Content-Type':MIME[path.extname(file).toLowerCase()] || 'application/octet-stream','Content-Length':stat.size,'X-Content-Type-Options':'nosniff'});
  if(req.method==='HEAD')res.end();else fs.createReadStream(file).on('error',()=>res.destroy()).pipe(res);
}
function officeBinary() {
  if(process.env.MAKEX_SOFFICE)return process.env.MAKEX_SOFFICE;
  for(const dir of [process.env.ProgramFiles,process.env['ProgramFiles(x86)']].filter(Boolean)) {
    const exe=path.join(dir,'LibreOffice','program','soffice.exe');if(fs.existsSync(exe))return exe;
  }
  return 'soffice';
}
const active = new Map();
async function convert(root,file) {
  const ppt=findPpt(root,file);if(!ppt)throw Object.assign(Error('找不到课件文件。请确认原附件仍在 E:\\ppt，或重新上传。'),{status:404});
  const st=fs.statSync(ppt);if(st.size>100*1024*1024)throw Object.assign(Error('课件超过 100 MB，请在 PowerPoint 中压缩后重试。'),{status:413});
  const id=crypto.createHash('sha256').update(fs.readFileSync(ppt)).digest('hex');
  const cache=path.join(root,'ppt-previews','converted',id);const pdf=path.join(cache,'preview.pdf');
  if(fs.existsSync(pdf))return {pdf:'ppt-previews/converted/'+id+'/preview.pdf'};
  if(active.has(id))return active.get(id);
  if(active.size>=1)throw Object.assign(Error('已有课件正在转换，请稍后重试。'),{status:429});
  const job=(async()=>{
    const tmp=await fs.promises.mkdtemp(path.join(os.tmpdir(),'makex-ppt-'));
    try{
      const input=path.join(tmp,'lesson'+path.extname(ppt).toLowerCase());await fs.promises.copyFile(ppt,input);
      const profile=require('node:url').pathToFileURL(path.join(tmp,'profile')).href;
      try { await run(officeBinary(),['-env:UserInstallation='+profile,'--headless','--convert-to','pdf','--outdir',tmp,input],{timeout:90000,maxBuffer:1024*1024,windowsHide:true}); }
      catch(e){throw Object.assign(Error(e.code==='ENOENT'?'此附件暂无网页预览。安装 LibreOffice 后重启服务，再点击转换；也可直接下载，用 PowerPoint 打开。':'课件转换未完成，请在 PowerPoint 中检查文件，或稍后重试。'),{status:503});}
      const output=path.join(tmp,'lesson.pdf');if(!fs.existsSync(output))throw Object.assign(Error('未能生成预览，请检查课件是否损坏或加密。'),{status:422});
      await fs.promises.mkdir(cache,{recursive:true});await fs.promises.copyFile(output,pdf);
      return {pdf:'ppt-previews/converted/'+id+'/preview.pdf'};
    }finally{await fs.promises.rm(tmp,{recursive:true,force:true});}
  })();active.set(id,job);try{return await job;}finally{active.delete(id);}
}
async function handle(req,res,root,localAllowed) {
 let u;try{u=new URL(req.url,'http://localhost');}catch{return false;}
 let pathname;try{pathname=decodeURIComponent(u.pathname);}catch{json(res,400,{error:'Invalid path'});return true;}
 if(pathname==='/ppt-preview/convert') {
   if(req.method!=='POST'||!localAllowed||req.headers['x-makex-preview']!=='1'){json(res,403,{error:'请从本机 MakeX 预览页面发起转换。'});return true;}
   try{json(res,200,await convert(root,u.searchParams.get('file')));}catch(e){json(res,e.status||500,{error:e.status?e.message:'无法生成预览，请重试。'});}return true;
 }
 if(!['GET','HEAD'].includes(req.method))return false;
 if(['/ppt-viewer.html','/ppt-viewer.js'].includes(pathname)){serve(req,res,inside(root,pathname.slice(1)));return true;}
 if(pathname.startsWith('/ppt-previews/')){serve(req,res,inside(path.join(root,'ppt-previews'),pathname.slice(14)));return true;}
 if(pathname.startsWith('/ppt/')){
   const rel=pathname.slice(5);const file=inside(path.join(root,'ppt'),rel)||inside(process.env.MAKEX_PPT_ROOT||'E:/ppt',rel);
   serve(req,res,file);return true;
 }
 return false;
}
module.exports={handle,inside,findPpt,convert};
