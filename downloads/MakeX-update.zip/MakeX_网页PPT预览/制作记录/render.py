import json,subprocess,os
from pathlib import Path
import fitz
ROOT=Path('/workspace/ChatGPT-caoweiming');WORK=Path('/workspace/ppt-work');m=json.load(open(WORK/'manifest.json'));pdfs=WORK/'pdf';pdfs.mkdir(exist_ok=True)
# One invocation reuses the office process and avoids repeated expensive initialization.
cmd=['soffice','-env:UserInstallation=file:///tmp/makex-office-render','--headless','--convert-to','pdf','--outdir',str(pdfs)]+[str(ROOT/d['file'])for d in m]
r=subprocess.run(cmd,stdout=open(WORK/'office-render.log','w'),stderr=subprocess.STDOUT,timeout=600)
if r.returncode:raise RuntimeError('Office conversion failed; inspect office-render.log')
for n,d in enumerate(m):
 pdf=pdfs/(Path(d['file']).stem+'.pdf')
 if not pdf.exists():raise RuntimeError('Missing PDF '+str(pdf))
 doc=fitz.open(pdf)
 if len(doc)!=d['pages']:raise RuntimeError('Page count mismatch '+d['id'])
 out=ROOT/'ppt-previews'/d['id'];out.mkdir(parents=True,exist_ok=True);d['slides']=[]
 for i,page in enumerate(doc):
  pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False);name=f'{i+1:03}.jpg';pix.save(out/name,jpg_quality=88);d['slides'].append(f'ppt-previews/{d["id"]}/{name}')
 print(d['id'],len(doc),'pages',flush=True)
(ROOT/'ppt-previews'/'index.json').write_text(json.dumps({'version':1,'decks':m},ensure_ascii=False,indent=2))
print('Total',sum(len(d['slides'])for d in m),flush=True)
