import json,re,html,math,hashlib
from pathlib import Path
from html.parser import HTMLParser
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR
ROOT=Path('/workspace/ChatGPT-caoweiming'); WORK=Path('/workspace/ppt-work')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[]
 def handle_starttag(self,t,a):
  if t in ['br','p','div','li','h1','h2','h3','tr']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['p','div','li','h1','h2','h3','tr']:self.parts.append('\n')
 def handle_data(self,s):self.parts.append(s)
def clean(s):
 p=Text();p.feed(s or '');s=html.unescape(''.join(p.parts));s=re.sub(r'[\ufffd\ue000-\uf8ff\x00-\x08\x0b\x0c\x0e-\x1f]','',s)
 return '\n'.join(re.sub(r'^[\s*•·⭐⚙✏✅]+','',x).strip() for x in s.splitlines() if x.strip())
def chunks(s,limit=190):
 result=[];current='';linecost=0
 for line in clean(s).splitlines():
  # Keep every source sentence, splitting at punctuation or at a safe character boundary.
  units=re.findall(r'.{1,90}(?:[。；！？]|$)|.{1,90}',line)
  for u in units:
   cost=math.ceil(len(u)/34)
   if (len(current)+len(u)>limit or linecost+cost>7) and current:result.append(current.strip());current='';linecost=0
   linecost+=cost
   current+=u+'\n'
 if current.strip():result.append(current.strip())
 return result
D=json.load(open(WORK/'original-makex_data.json'))
OUTLINES={
18:('Onshape 与激光雕刻入门（一）',[
('认识设计到加工的流程','登录 Onshape 并新建设计文档；认识草图、尺寸约束和零件。\n比较三维模型与二维轮廓：激光切割通常需要闭合的二维轮廓。\n本节成果：一个标注尺寸的简单名牌设计。'),
('草图与尺寸','选择基准面建立草图，绘制矩形外框。\n添加长度、宽度和圆孔尺寸；单位统一为毫米。\n检查重复线、未闭合轮廓和孔边剩余材料。'),
('导出前检查','根据设备软件要求导出 DXF 或 SVG，导入后核对单位和实际尺寸。\n区分切割线与雕刻区域；先用纸样核对大小。\n学生只完成设计和检查，由受训教师设置设备参数。'),
('安全与验证','只使用设备厂商明确允许的材料；禁止切割 PVC 和未知塑料。\n保持抽排风与联锁有效，运行期间不得离人，不直视激光。\n教师先做小样；学生比较成品尺寸与设计尺寸并记录差异。')]),
19:('Onshape 与激光雕刻进阶（二）',[
('复习与任务','建议任务：设计一块带孔位的连接板。\n先测量连接对象的实际孔距、螺丝直径和材料厚度，再建立草图。'),
('约束与定位','以基准边或中心线定位孔心，添加水平、垂直和相等约束。\n使用尺寸约束表达孔距，不依靠目测拖动。\n检查草图是否存在多余约束或未闭合轮廓。'),
('试片与公差','制作小孔试片，教师在允许材料上试切。\n测量成品孔径与外形尺寸，认识切缝造成的尺寸偏差。\n根据实际装配效果修订设计，参数由具体设备和材料试验确定。'),
('装配检查','确认孔位能与实物对齐，螺丝可安装且边缘不易破裂。\n记录设计值、实测值和修改理由。\n激光操作由受训教师完成，保持通风、联锁和全程看护。')]),
20:('Onshape 与激光雕刻项目（三）',[
('项目需求','建议任务：设计可装配的桌面小支架。\n明确承载物尺寸、支架高度和稳定性要求，先绘制纸上方案。'),
('拆分二维零件','把支架拆成底板和支撑板，标注材料厚度及插槽位置。\n先做纸板验证，检查干涉和装配方向，再细化 Onshape 草图。'),
('加工准备','逐件核对闭合轮廓、单位、数量与排版。\n教师选择已批准材料，使用试片验证槽宽与厚度配合；不要套用未经测试的功率速度。'),
('迭代与展示','组装后检查晃动、承载与边缘质量；记录问题并修改草图。\n展示需求、第一版、测量记录和改进版。\n使用激光设备时保持抽排风、联锁及全程看护。')]),
21:('Onshape 螺丝量规制作',[
('明确量规用途','建议任务：制作帮助区分常用螺丝外径的比对板。\n用游标卡尺测量手边螺丝，记录实测外径；本量规不用于判断螺纹牙距或作为精密检验工具。'),
('建立参数草图','绘制量规外框，按实测直径设计一组测试孔并添加文字标签。\n孔间和孔边保留足够材料，具体余量由材料和试片强度验证。'),
('先做孔径试片','导出设备支持的二维文件，核对毫米单位。\n由教师试切小样，测量实际孔径，选择适合比对的间隙并修改设计。'),
('使用与验证','用已知规格螺丝逐一验证，记录可通过、过松、不能通过。\n保留实际孔径记录，说明不同材料和设备可能产生不同切缝。\n只使用批准材料；教师操作激光设备并保持抽排风和全程看护。')]),
29:('AI Camera 自动瞄准与广域搜索',[
('任务与观测量','课程主题提出：看到其他 AprilTag，根据其位置推断转向。\n建议任务：目标标签暂时不可见时，利用已知标签关系辅助搜索；最终是否得分必须由实测确认。'),
('先建立标签地图','教师确认目标与参考标签的固定相对位置，记录朝向与编号。\n没有标定关系时，不能仅凭标签编号推断目标方位。\n先识别可见标签，校验编号、位置数据及有效状态。'),
('设计搜索状态机','划分搜索、发现参考、转向、目标确认、瞄准五个状态。\n数据无效时停止使用旧偏差；限制搜索速度与持续时间。\n参考标签只辅助粗定位，看到目标后再依据目标偏差精调。'),
('分步测试','先静止验证标签识别，再低速测试左右转向，最后加入目标丢失和误识别情境。\n记录成功次数、搜索时间和偏差；修改前后在相同场景复测。\n投射或运动机构测试前清空危险区域，由教师确认安全。')])}
COL={'bg':'102F31','panel':'194244','mint':'70E0B3','text':'F4F3E8','muted':'B2C9C4','gold':'F2CA79'}
def rgb(c):return RGBColor.from_string(COL.get(c,c))
def box(sl,x,y,w,h,color,shape=MSO_SHAPE.RECTANGLE):
 sh=sl.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h));sh.fill.solid();sh.fill.fore_color.rgb=rgb(color);sh.line.fill.background();return sh
def text(sl,s,x,y,w,h,size=22,color='text',bold=False):
 sh=sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h));tf=sh.text_frame;tf.word_wrap=True;tf.margin_left=Inches(.02);tf.margin_right=Inches(.02);tf.margin_top=0;tf.margin_bottom=0
 for i,line in enumerate(s.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.font.name='Noto Sans CJK SC';p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=rgb(color);p.space_after=Pt(10)
 return sh
def base(prs,code,n,section):
 sl=prs.slides.add_slide(prs.slide_layouts[6]);sl.background.fill.solid();sl.background.fill.fore_color.rgb=rgb('bg');box(sl,.48,.45,.1,.32,'mint');text(sl,'Kclub  /  MakeX',.75,.43,7,.35,14,'mint',True);text(sl,section,9,.43,3.6,.35,12,'muted');box(sl,.65,6.91,12,.015,'panel');text(sl,code,.7,7.07,11,.25,10,'muted');text(sl,f'{n:02}',12,7.02,.6,.3,13,'mint');return sl
def title_slide(prs,title,subtitle,code,draft):
 sl=base(prs,code,1,'课程课件 · 建议教学稿' if draft else '课程课件');text(sl,title,.8,1.5,11.6,2.1,36,'text',True);text(sl,subtitle or '观察 · 实践 · 验证 · 迭代',.85,3.8,11.3,1.2,21,'muted')
 for j,label in enumerate(['认识问题','动手实践','记录与复盘']):box(sl,.85+j*4.08,5.7,3.8,.65,'panel',MSO_SHAPE.ROUNDED_RECTANGLE);text(sl,label,1.05+j*4.08,5.85,3.35,.4,17,'mint')
def body(prs,title,content,code,section,n,draft=False):
 sl=base(prs,code,n,section);text(sl,title,.8,1.06,11.7,.85,28,'text',True);box(sl,.8,2.12,11.7,4.45,'panel',MSO_SHAPE.ROUNDED_RECTANGLE)
 lines=content.splitlines();maxlen=max(map(len,lines),default=0);size=22 if len(content)<170 else 20
 # At <=190 CJK characters a content panel fits in <=8 lines at 20pt.
 text(sl,content,1.15,2.47,10.95,3.8,size,'text')
 if draft:text(sl,'建议教学内容 · 请教师结合器材与课时确认',.85,6.65,11,.25,10,'gold')
manifest=[];contentlog=[]
for cat,courses in D.items():
 for idx,c in enumerate(courses):
  if not c.get('name') or re.fullmatch(r'新课程\s*\d+',c['name']):continue
  if any(re.search(r'\.pptx?$',p.get('name',''),re.I) for p in c.get('ppts',[])):continue
  code=f'{cat}-{idx+1:02}';draft=cat=='explorer' and idx in OUTLINES
  title=OUTLINES[idx][0] if draft else clean(c['name']);prs=Presentation();prs.slide_width=Inches(13.333);prs.slide_height=Inches(7.5)
  title_slide(prs,title,clean(c.get('subtitle')),code,draft)
  sections=[]
  if draft:
   sections.append(('使用说明','该课程目前只有主题，缺少正式教案。\n以下为围绕课程主题编写的建议教学稿，需教师确认任务、器材、设备参数与课堂安排后使用。\n未修改课程系统中的原始正文。','教师说明'))
   for t,ct in OUTLINES[idx][1]:
    for j,part in enumerate(chunks(ct)):sections.append((t+(f' · {j+1}' if j else ''),part,'建议教学流程'))
  else:
   eq=clean(c.get('equipment'))
   if eq:sections.append(('课前准备',eq[:190],'准备'))
   for label,key in [('本课学习目标','objectives'),('课堂探究与实践','procedure')]:
    for j,part in enumerate(chunks(c.get(key,''))):sections.append((label+f'  {j+1:02}',part,label))
  sections.extend([
   ('实践记录单','任务 / 实现了什么？\n证据 / 记录测量值、截图或作品。\n问题 / 哪一步与预期不同？\n改进 / 只改变一个条件，再比较结果。','课堂记录'),
   ('展示与复盘','用自己的话解释本课关键原理。\n演示一项完成的任务，并说明判断成功的依据。\n分享一次调试：现象 → 原因 → 修改 → 复测。\n整理器材，保存程序、模型和实验记录。','总结')])
  for n,(t,ct,section) in enumerate(sections,2):body(prs,t,ct,code,section,n,draft)
  name=f'{code}_{re.sub(r"[<>:\"/\\|?*]","_",title)}.pptx';rel=f'ppt/{cat}/{name}';dest=ROOT/rel;dest.parent.mkdir(parents=True,exist_ok=True);prs.save(dest)
  attach={'name':name,'path':rel,'previewId':code,'generated':True,'draft':draft}
  c.setdefault('ppts',[]).append(attach)
  manifest.append({'id':code,'category':cat,'index':idx,'title':title,'file':rel,'pages':len(prs.slides),'draft':draft,'sourceHadReplacementCharacters':'\ufffd' in str(c.get('procedure',''))})
  contentlog.append({'id':code,'title':title,'slides':[{'title':t,'text':ct}for t,ct,s in sections]})
json.dump(D,open(ROOT/'makex_data.json','w'),ensure_ascii=False,indent=2)
json.dump(manifest,open(WORK/'manifest.json','w'),ensure_ascii=False,indent=2)
json.dump(contentlog,open(WORK/'slide-content.json','w'),ensure_ascii=False,indent=2)
print('Generated',len(manifest),'decks,',sum(x['pages']for x in manifest),'slides; drafts',sum(x['draft']for x in manifest))
