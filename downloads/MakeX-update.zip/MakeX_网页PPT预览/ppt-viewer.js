'use strict';
(async function(){
 const $=id=>document.getElementById(id),params=new URLSearchParams(location.search);
 const file=params.get('file')||'',id=params.get('id')||'';
 let pages=[],at=0;
 const base=new URL('.',location.href);
 const status=s=>{$('status').textContent=s;};
 const safeFile=/^(?:ppt\/)?[^\0\\]+\.pptx?$/i.test(file)&&!file.split('/').some(x=>x==='..'||x==='.');
 if(!safeFile){status('无效的课件路径，请从课程附件列表重新打开。');return;}
 const urlPath=p=>p.split('/').map(encodeURIComponent).join('/');
 const original=new URL(file.startsWith('ppt/')?urlPath(file):'ppt/'+urlPath(file),base);
 $('download').href=original.href;$('download').hidden=false;
 $('title').textContent=file.split('/').pop();
 function show(i){
  at=Math.max(0,Math.min(pages.length-1,i));$('slide').src=new URL(pages[at],base).href;$('slide').alt=$('title').textContent+' · 第 '+(at+1)+' 页';
  $('page').value=at+1;$('total').textContent=pages.length;$('fs-counter').textContent=(at+1)+' / '+pages.length;
  $('prev').disabled=$('fs-prev').disabled=at===0;$('next').disabled=$('fs-next').disabled=at===pages.length-1;
  Array.from($('thumbs').children).forEach((b,n)=>b.setAttribute('aria-current',String(n===at)));
 }
 $('prev').onclick=$('fs-prev').onclick=()=>show(at-1);$('next').onclick=$('fs-next').onclick=()=>show(at+1);
 $('page').onchange=()=>{const n=Number($('page').value);show(Number.isFinite(n)?Math.round(n)-1:at);};
 $('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('stage').requestFullscreen();}catch{status('浏览器暂不支持全屏，请使用窗口最大化。');}};
 $('fs-exit').onclick=()=>document.exitFullscreen();
 document.addEventListener('keydown',e=>{if(!pages.length||/INPUT|TEXTAREA/.test(e.target.tagName))return;const actions={ArrowLeft:at-1,ArrowRight:at+1,Home:0,End:pages.length-1};if(e.key in actions){e.preventDefault();show(actions[e.key]);}});
 $('slide').onerror=()=>status('预览图片未找到，请完整解压更新包，保留 ppt-previews 文件夹。');
 function pdf(url){$('pdf').src=new URL(url,base).href;$('pdf').hidden=false;status('已转换为 PDF 预览，可使用内置工具栏翻页。若浏览器无法显示，请下载 PPT 用 PowerPoint 打开。');}
 try{
  const response=await fetch(new URL('ppt-previews/index.json',base));if(!response.ok)throw Error('missing manifest');const manifest=await response.json();
  const deck=manifest.decks.find(d=>(id?d.id===id:d.file===file)&&d.file===file);
  if(deck&&Array.isArray(deck.slides)&&deck.slides.length){
   if(!deck.slides.every(p=>/^ppt-previews\/[a-z0-9-]+\/\d+\.jpg$/.test(p)))throw Error('invalid slide path');
   pages=deck.slides;$('title').textContent=deck.title;$('slide').hidden=false;$('controls').hidden=false;
   for(let i=0;i<pages.length;i++){const b=document.createElement('button');b.setAttribute('aria-label','第 '+(i+1)+' 页');const img=document.createElement('img');img.src=new URL(pages[i],base).href;img.loading='lazy';img.alt=String(i+1);b.append(img);b.onclick=()=>show(i);$('thumbs').append(b);}
   show(0);status(deck.draft?'建议教学稿：该课程原来只有主题，请教师核对后使用。':'已加载 '+pages.length+' 页课件，支持离线翻页与全屏。');return;
  }
 }catch{}
 status('此附件暂未附带预览。可下载原 PPT，或在安装 LibreOffice 的本机服务器中转换。原附件需仍保存在 E:\\ppt。');
 if(location.protocol==='file:'){status('直接打开文件时浏览器可能阻止读取预览。请双击“启动MakeX.bat”，再从课程附件打开；静态网站也可读取随包预览。');return;}
 $('convert').hidden=false;$('convert').onclick=async()=>{
  $('convert').disabled=true;status('正在转换，请稍候（最多约 90 秒）…');
  try{const r=await fetch(new URL('ppt-preview/convert?file='+encodeURIComponent(file),base),{method:'POST',headers:{'X-MakeX-Preview':'1'}});const result=await r.json();if(!r.ok)throw Error(result.error||'转换失败');pdf(result.pdf);$('convert').hidden=true;}
  catch(e){status(e.message);}finally{$('convert').disabled=false;}
 };
})();
