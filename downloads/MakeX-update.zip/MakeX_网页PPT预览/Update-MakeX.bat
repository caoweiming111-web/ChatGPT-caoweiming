@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
set "MAKEX_NODE=node"
where node >nul 2>nul
if not errorlevel 1 goto run_update
if exist "D:\node.exe" goto use_fallback
echo Node.js was not found. Please install Node.js and try again.
pause
exit /b 1
:use_fallback
set "MAKEX_NODE=D:\node.exe"
:run_update
"%MAKEX_NODE%" "%~dp0update-courseware.js" --interactive
set "MAKEX_RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %MAKEX_RESULT%
