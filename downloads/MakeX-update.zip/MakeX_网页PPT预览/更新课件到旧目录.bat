@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 请先在网页保存课程，并关闭旧的 MakeX 服务器窗口。
echo 本工具会备份原文件，保留课程正文和原附件，仅追加新课件。
set /p "MAKEX_TARGET=请输入旧版 MakeX 文件夹路径（可拖入文件夹后按回车）："
set "MAKEX_TARGET=%MAKEX_TARGET:"=%"
set "MAKEX_NODE=node"
where node >nul 2>nul
if errorlevel 1 (
 if exist "D:\node.exe" (set "MAKEX_NODE=D:\node.exe") else (
  echo 请先安装 Node.js。
  pause
  exit /b 1
 )
)
"%MAKEX_NODE%" "%~dp0update-courseware.js" "%MAKEX_TARGET%"
pause
