@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
set "MAKEX_LOG=%~dp0makex-update-result.txt"
set "MAKEX_NODE=node"
> "%MAKEX_LOG%" echo MakeX direct update log
where node >nul 2>nul
if not errorlevel 1 goto run_update
if exist "D:\node.exe" goto use_fallback
>> "%MAKEX_LOG%" echo ERROR: Node.js was not found.
goto show_result
:use_fallback
set "MAKEX_NODE=D:\node.exe"
:run_update
"%MAKEX_NODE%" "%~dp0run-makex-update.js" "C:\Users\51155\Documents\Codex\2026-06-13\https-caoweiming111-web-github-io-makex" >> "%MAKEX_LOG%" 2>&1
set "MAKEX_RESULT=%ERRORLEVEL%"
>> "%MAKEX_LOG%" echo Exit code: %MAKEX_RESULT%
:show_result
type "%MAKEX_LOG%"
echo.
echo Log saved to: "%MAKEX_LOG%"
pause
