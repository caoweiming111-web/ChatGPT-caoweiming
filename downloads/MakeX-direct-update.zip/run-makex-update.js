'use strict';
// Synchronous entry point: no terminal input, promises, or platform dialogs.
console.log('MakeX direct updater');
console.log('Node: '+process.version);
console.log('Source: '+__dirname);
console.log('Target: '+(process.argv[2]||'(missing)'));
try {
 if(!process.argv[2])throw Error('缺少旧程序目录参数，未更新任何文件。');
 const {update}=require('./update-courseware');
 const report=update(process.argv[2]);
 console.log('\nUPDATE_OK');
 console.log('更新完成，追加课件记录：'+report.added+'。');
 console.log('原文件备份：'+report.backup);
 if(report.unmatched.length)console.log('未自动匹配的课程：\n'+report.unmatched.join('\n'));
 console.log('请从旧程序目录运行 启动MakeX.bat。');
} catch(error) {
 console.error('\nUPDATE_FAILED');
 console.error('更新失败：'+error.message);
 console.error(error.stack);
 process.exitCode=1;
}
